export enum Category {
  Study = "Study",
  Faith = "Faith",
  Personal = "Personal",
  Work = "Work",
  Health = "Health",
}

export enum Priority {
  High = "High",
  Medium = "Medium",
  Low = "Low",
}

export enum EnergyLevel {
  High = "High",
  Normal = "Normal",
  Low = "Low",
}

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
  estimatedMinutes?: number;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  category: Category;
  priority: Priority;
  energyLevel: EnergyLevel;
  estimatedMinutes: number;
  focusTimeSpent: number;
  subtasks: SubTask[];
  status: "todo" | "in_progress" | "completed";
  dueDate: string;
  projectId?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  color: string;
}

export interface Habit {
  id: string;
  name: string;
  frequency: "Daily" | "Weekly";
  category: Category;
  streak: number;
  completedDays: string[]; // YYYY-MM-DD
  lastCompletedDate?: string;
  consistencyScore: number; // 0-100
}

export interface Goal {
  id: string;
  title: string;
  targetDate: string;
  category: Category;
  progress: number; // 0-100
  subGoals: { id: string; title: string; completed: boolean }[];
  status: "active" | "completed";
}

export interface TimelineItem {
  id: string;
  time: string; // e.g. "08:00"
  title: string;
  type: "Prayer" | "Study" | "Exercise" | "Focus" | "Meeting" | "Reading" | "Sleep" | "Other";
  completed: boolean;
  notes?: string;
}

export interface FocusLog {
  id: string;
  duration: number; // in minutes
  timestamp: string; // ISO string
  category: Category;
}

export interface DailyPrayer {
  id: string;
  name: "Fajr" | "Dhuhr" | "Asr" | "Maghrib" | "Isha";
  time: string;
  completed: boolean;
}

export interface DhikrCounter {
  id: string;
  phrase: string;
  meaning: string;
  count: number;
  target: number;
}

export interface FaithState {
  prayers: DailyPrayer[];
  quranGoal: {
    targetPages: number;
    pagesReadToday: number;
    streak: number;
  };
  dhikr: DhikrCounter[];
  faithStreak: number;
  dailyDua: {
    arabic: string;
    translation: string;
    meaning: string;
  };
}

export interface Note {
  id: string;
  title: string;
  content: string;
  updatedAt: string;
  category: Category;
}

export interface AssistantMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
}

export interface ProductivityInsights {
  focusScore: number;
  scoreJustification: string;
  productivityDiscovery: string;
  faithBalanceInsight: string;
  immediateAction: string;
}
