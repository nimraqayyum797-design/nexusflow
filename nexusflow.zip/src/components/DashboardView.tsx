import { useState } from "react";
import { motion } from "motion/react";
import {
  Zap,
  CheckCircle2,
  BookOpen,
  Heart,
  Activity,
  Plus,
  Compass,
  AlertCircle,
  TrendingUp,
  Droplet,
  Tv,
  Brain,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { Task, Habit, DailyPrayer, TimelineItem } from "../types";

interface DashboardViewProps {
  tasks: Task[];
  habits: Habit[];
  prayers: DailyPrayer[];
  timeline: TimelineItem[];
  focusTimeToday: number; // in minutes
  studyTimeToday: number; // in hours
  waterIntake: number; // in ml
  setWaterIntake: (val: number) => void;
  togglePrayer: (id: string) => void;
  toggleTimelineItem: (id: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  accentColor: string;
}

export default function DashboardView({
  tasks,
  habits,
  prayers,
  timeline,
  focusTimeToday,
  studyTimeToday,
  waterIntake,
  setWaterIntake,
  togglePrayer,
  toggleTimelineItem,
  setActiveTab,
  accentColor,
}: DashboardViewProps) {
  const completedTasksCount = tasks.filter((t) => t.status === "completed").length;
  const totalTasksCount = tasks.length;
  
  const completedHabitsCount = habits.filter((h) => {
    const todayStr = new Date().toISOString().split("T")[0];
    return h.completedDays.includes(todayStr);
  }).length;
  const totalHabitsCount = habits.length;

  const completedPrayersCount = prayers.filter((p) => p.completed).length;
  const totalPrayersCount = prayers.length;

  // Compute standard Productivity Score (0-100)
  const taskRatio = totalTasksCount > 0 ? (completedTasksCount / totalTasksCount) * 40 : 25;
  const habitRatio = totalHabitsCount > 0 ? (completedHabitsCount / totalHabitsCount) * 30 : 20;
  const prayerRatio = totalPrayersCount > 0 ? (completedPrayersCount / totalPrayersCount) * 20 : 15;
  const focusRatio = Math.min((focusTimeToday / 120) * 10, 10);
  const productivityScore = Math.round(taskRatio + habitRatio + prayerRatio + focusRatio);

  const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
  const [aiSummaryText, setAiSummaryText] = useState(
    "Good Morning Nimra! Your flow looks highly optimized today. Fajr prayer is logged successfully. You have a study session at 10 AM, and an executive briefing on 'AI Productivity' at 3 PM. Suggest allocating 45 minutes for task breakdowns."
  );

  const handleRefreshAISummary = async () => {
    setAiSummaryLoading(true);
    try {
      const response = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assistantType: "coach",
          messages: [
            {
              role: "user",
              content: `Give me a very short 2-3 sentence strategic briefing for my day.
Completed tasks: ${completedTasksCount}/${totalTasksCount}
Completed habits: ${completedHabitsCount}/${totalHabitsCount}
Prayers logged: ${completedPrayersCount}/${totalPrayersCount}
Focus time: ${focusTimeToday} minutes.
Keep the tone exceptionally polished, luxurious, and motivational for Nimra.`,
            },
          ],
        }),
      });
      const data = await response.json();
      if (data.text) {
        setAiSummaryText(data.text);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAiSummaryLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-extrabold tracking-tight text-white"
          >
            Good Morning, Nimra 👋
          </motion.h1>
          <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
            Let's make today exceptionally meaningful and productive.
          </p>
        </div>

        {/* Dynamic Energy Indicator */}
        <div className="flex items-center gap-3 bg-[#1C1C1C] border border-[#2C2C2C] px-4 py-2.5 rounded-2xl">
          <Brain size={18} style={{ color: accentColor }} className="animate-pulse" />
          <div className="text-xs">
            <span className="text-gray-400 block font-medium">Energy Prediction</span>
            <span className="text-white font-bold">Peak (9 AM - 12 PM)</span>
          </div>
        </div>
      </div>

      {/* AI Assistant Smart Summary Card */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="p-6 rounded-3xl bg-linear-to-r from-[#1C1C1C] via-[#141414] to-[#1C1C1C] border border-[#2C2C2C] relative overflow-hidden group shadow-lg"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#B6FF4D]/3 rounded-full blur-3xl pointer-events-none group-hover:scale-110 transition-transform"></div>
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-neutral-800 border border-[#2C2C2C] flex items-center justify-center">
              <Sparkles size={16} style={{ color: accentColor }} />
            </div>
            <h2 className="text-lg font-bold text-white tracking-wide">NexusAI Flow Briefing</h2>
          </div>
          <button
            onClick={handleRefreshAISummary}
            disabled={aiSummaryLoading}
            className="px-3 py-1.5 rounded-lg border border-[#2C2C2C] hover:bg-[#2C2C2C] text-xs font-semibold text-[#BDBDBD] hover:text-white transition-all cursor-pointer disabled:opacity-50"
          >
            {aiSummaryLoading ? "Generating..." : "Regenerate Briefing"}
          </button>
        </div>
        <p className="text-sm text-[#BDBDBD] leading-relaxed mt-4 font-medium max-w-4xl">
          {aiSummaryText}
        </p>
        <div className="flex flex-wrap items-center gap-6 mt-5 text-xs text-[#BDBDBD] font-semibold border-t border-[#2C2C2C]/50 pt-4">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-400"></div>
            <span>Priority: Study Session</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
            <span>Next Prayer: Dhuhr (In 2h)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400"></div>
            <span>Habit streak: 5 days</span>
          </div>
        </div>
      </motion.div>

      {/* Grid of Micro-Metrics (Premium SaaS Style Dashboard Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Metric 2: Task Completion */}
        <motion.div
          whileHover={{ y: -4 }}
          className="p-5 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] flex flex-col justify-between h-40 group cursor-pointer transition-all duration-300"
          onClick={() => setActiveTab("tasks")}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-400 tracking-wider">TASKS LOG</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <CheckCircle2 size={16} />
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-extrabold text-white tracking-tight">
              {completedTasksCount}/{totalTasksCount}
            </h3>
            <div className="mt-2 flex items-center justify-between text-[11px] text-[#BDBDBD]">
              <span className="font-semibold">Done Today</span>
              <span className="text-emerald-400 font-bold">
                {totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0}%
              </span>
            </div>
            <div className="w-full bg-[#2C2C2C] h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${totalTasksCount > 0 ? (completedTasksCount / totalTasksCount) * 100 : 0}%`,
                }}
              ></div>
            </div>
          </div>
        </motion.div>

        {/* Metric 3: Study Hours */}
        <motion.div
          whileHover={{ y: -4 }}
          className="p-5 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] flex flex-col justify-between h-40 group cursor-pointer transition-all duration-300"
          onClick={() => setActiveTab("study")}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-400 tracking-wider">STUDY SESSIONS</span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400">
              <BookOpen size={16} />
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-extrabold text-white tracking-tight">{studyTimeToday} hrs</h3>
            <div className="mt-2 flex items-center justify-between text-[11px] text-[#BDBDBD]">
              <span className="font-semibold">Goal: 4 hrs</span>
              <span className="text-blue-400 font-bold">{Math.round((studyTimeToday / 4) * 100)}%</span>
            </div>
            <div className="w-full bg-[#2C2C2C] h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-blue-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min((studyTimeToday / 4) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        </motion.div>

        {/* Metric 4: Productivity / AI Score */}
        <motion.div
          whileHover={{ y: -4 }}
          className="p-5 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] flex flex-col justify-between h-40 group cursor-pointer transition-all duration-300"
          onClick={() => setActiveTab("analytics")}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-400 tracking-wider">PRODUCTIVITY FLOW INDEX</span>
            <div
              className="w-8 h-8 rounded-xl flex items-center justify-center text-black"
              style={{ backgroundColor: accentColor }}
            >
              <TrendingUp size={16} />
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-extrabold text-white tracking-tight">{productivityScore}</h3>
            <div className="mt-2 flex items-center justify-between text-[11px] text-[#BDBDBD]">
              <span className="font-semibold">AI Calculated Flow</span>
              <span style={{ color: accentColor }} className="font-bold">
                {productivityScore > 80 ? "Excellent" : productivityScore > 50 ? "Steady" : "Action Needed"}
              </span>
            </div>
            <div className="w-full bg-[#2C2C2C] h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${productivityScore}%`,
                  backgroundColor: accentColor,
                }}
              ></div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Hydration and Screen Time Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Prayer Progress Card */}
        <div className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C]">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-4 mb-4">
            <div className="flex items-center gap-2.5">
              <Compass className="text-emerald-400" size={18} />
              <h3 className="text-sm font-bold text-white tracking-wide">Prayer Streak tracker</h3>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
              {completedPrayersCount}/5 completed
            </span>
          </div>
          <div className="flex flex-col gap-3">
            {prayers.map((p) => (
              <div
                key={p.id}
                onClick={() => togglePrayer(p.id)}
                className="flex items-center justify-between p-3 rounded-xl bg-[#141414] border border-[#2C2C2C] hover:border-emerald-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                      p.completed
                        ? "bg-emerald-500 border-emerald-500 text-black"
                        : "border-[#2C2C2C] group-hover:border-[#BDBDBD]"
                    }`}
                  >
                    {p.completed && <CheckCircle2 size={12} strokeWidth={3} />}
                  </div>
                  <span className={`text-sm font-semibold ${p.completed ? "text-[#BDBDBD] line-through" : "text-white"}`}>
                    {p.name}
                  </span>
                </div>
                <span className="text-xs text-gray-500 font-medium">{p.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Smart timeline card */}
        <div className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] md:col-span-2">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-4 mb-4">
            <div className="flex items-center gap-2.5">
              <Zap size={18} style={{ color: accentColor }} />
              <h3 className="text-sm font-bold text-white tracking-wide">Today's Smart Timeline</h3>
            </div>
            <span className="text-xs font-bold text-[#BDBDBD]">July 23, 2026 (Thursday)</span>
          </div>

          <div className="relative border-l border-[#2C2C2C] pl-6 ml-3 space-y-5">
            {timeline.map((item) => (
              <div key={item.id} className="relative group">
                {/* Timeline node circle */}
                <div
                  onClick={() => toggleTimelineItem(item.id)}
                  className={`absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-2 cursor-pointer transition-all flex items-center justify-center ${
                    item.completed
                      ? "bg-[#B6FF4D] border-[#B6FF4D]"
                      : "bg-[#1C1C1C] border-[#2C2C2C] group-hover:border-white"
                  }`}
                >
                  {item.completed && <CheckCircle2 size={10} className="text-black" strokeWidth={3} />}
                </div>

                <div className="flex items-start justify-between p-3.5 rounded-xl bg-[#141414] border border-[#2C2C2C] group-hover:border-[#2C2C2C] transition-all">
                  <div>
                    <span className="text-[10px] font-bold text-gray-500 block uppercase tracking-wider">
                      {item.time}
                    </span>
                    <span
                      className={`text-sm font-bold mt-1 block ${
                        item.completed ? "text-[#BDBDBD] line-through" : "text-white"
                      }`}
                    >
                      {item.title}
                    </span>
                    {item.notes && <p className="text-xs text-gray-500 mt-1">{item.notes}</p>}
                  </div>

                  <span
                    className={`text-[10px] px-2.5 py-1 rounded-full font-bold uppercase ${
                      item.type === "Prayer"
                        ? "bg-emerald-500/10 text-emerald-400"
                        : item.type === "Study"
                        ? "bg-blue-500/10 text-blue-400"
                        : item.type === "Focus"
                        ? "bg-amber-500/10 text-amber-400"
                        : "bg-purple-500/10 text-purple-400"
                    }`}
                  >
                    {item.type}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Water and screen time controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Hydration Tracker */}
        <div className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] flex items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Droplet className="text-blue-400 animate-bounce" size={20} />
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">Water Intake</h4>
            </div>
            <p className="text-2xl font-extrabold text-white">{waterIntake} ml</p>
            <p className="text-xs text-[#BDBDBD]">Hydration status: Optimal. Target: 2500 ml</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setWaterIntake(Math.max(0, waterIntake - 250))}
              className="px-3.5 py-2 rounded-xl bg-[#141414] border border-[#2C2C2C] text-sm text-[#BDBDBD] font-bold hover:text-white hover:bg-[#2C2C2C] transition-all cursor-pointer"
            >
              -250 ml
            </button>
            <button
              onClick={() => setWaterIntake(waterIntake + 250)}
              className="px-3.5 py-2 rounded-xl text-black font-bold text-sm hover:opacity-95 transition-all cursor-pointer"
              style={{ backgroundColor: accentColor }}
            >
              +250 ml
            </button>
          </div>
        </div>

        {/* Screen Time tracking */}
        <div className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] flex items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Tv className="text-red-400" size={20} />
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">Screen Time</h4>
            </div>
            <p className="text-2xl font-extrabold text-white">3.4 hrs</p>
            <p className="text-xs text-[#BDBDBD]">Down by 1.2 hrs compared to yesterday</p>
          </div>
          <div className="text-xs px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
            -25% improvement
          </div>
        </div>
      </div>
    </div>
  );
}
