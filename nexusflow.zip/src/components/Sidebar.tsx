import { motion } from "motion/react";
import Logo from "./Logo";
import {
  LayoutDashboard,
  Sparkles,
  Zap,
  CheckSquare,
  Target,
  Repeat,
  BookOpen,
  Calendar,
  Briefcase,
  BookText,
  BarChart3,
  Settings,
  User,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  accentColor: string;
  currentUser: { name: string; email: string; role: string } | null;
  onLogOut: () => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  collapsed,
  setCollapsed,
  accentColor,
  currentUser,
  onLogOut,
}: SidebarProps) {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "assistant", label: "AI Assistant", icon: Sparkles },
    { id: "tasks", label: "Tasks", icon: CheckSquare },
    { id: "goals", label: "Goals", icon: Target },
    { id: "habits", label: "Habits", icon: Repeat },
    { id: "study", label: "Study Hub", icon: BookOpen },
    { id: "islamic", label: "Islamic Companion", icon: BookText },
    { id: "calendar", label: "Smart Calendar", icon: Calendar },
    { id: "journal", label: "Notes & Journal", icon: BookText },
    { id: "analytics", label: "AI Analytics", icon: BarChart3 },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <motion.aside
      initial={{ width: collapsed ? 80 : 280 }}
      animate={{ width: collapsed ? 80 : 280 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="h-screen bg-[#141414] border-r border-[#2C2C2C] flex flex-col justify-between sticky top-0 z-40 select-none overflow-hidden shrink-0"
    >
      {/* Header with Luxury Logo */}
      <div className="p-4 flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center overflow-hidden">
            <Logo
              size={collapsed ? 36 : 40}
              showText={!collapsed}
              textClassName="text-base font-black tracking-wider"
              accentColor={accentColor}
            />
          </div>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-8 h-8 rounded-lg border border-[#2C2C2C] hover:bg-[#1C1C1C] flex items-center justify-center transition-all cursor-pointer text-gray-400 hover:text-white"
          >
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex flex-col gap-1.5 mt-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative flex items-center gap-3.5 px-3 py-3 rounded-xl text-sm font-medium transition-all group duration-200 cursor-pointer w-full text-left`}
                style={{
                  color: isActive ? "#000000" : "#BDBDBD",
                  backgroundColor: isActive ? accentColor : "transparent",
                }}
              >
                <div className={`shrink-0 ${isActive ? "text-black" : "text-gray-400 group-hover:text-white transition-colors"}`}>
                  <Icon size={18} />
                </div>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="truncate"
                  >
                    {item.label}
                  </motion.span>
                )}
                {/* Tooltip for collapsed sidebar */}
                {collapsed && (
                  <div className="absolute left-20 bg-[#1C1C1C] border border-[#2C2C2C] text-white text-xs py-1.5 px-3 rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap shadow-xl">
                    {item.label}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* User Profile and Bottom Actions */}
      <div className="p-4 border-t border-[#2C2C2C] flex flex-col gap-3">
        {/* User profile card */}
        <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-[#1C1C1C] border border-[#2C2C2C] overflow-hidden">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-9 h-9 rounded-full bg-[#2C2C2C] flex items-center justify-center shrink-0">
              <User size={16} className="text-gray-400" />
            </div>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col overflow-hidden animate-none"
              >
                <span className="text-sm font-semibold text-white truncate">
                  {currentUser?.name || "Nimra"} 👋
                </span>
                <span className="text-xs text-[#BDBDBD] truncate">
                  {currentUser?.role || "Productive Creator"}
                </span>
              </motion.div>
            )}
          </div>
          {!collapsed && (
            <button
              onClick={onLogOut}
              title="Log Out of Workspace"
              className="p-1.5 hover:bg-[#2C2C2C] rounded-lg transition-colors text-gray-400 hover:text-rose-400 cursor-pointer"
            >
              <LogOut size={15} />
            </button>
          )}
        </div>

        {/* Collapsed state quick log-out option */}
        {collapsed && (
          <button
            onClick={onLogOut}
            title="Log Out of Workspace"
            className="w-full h-9 flex items-center justify-center bg-rose-950/20 border border-rose-900/30 hover:bg-rose-950/40 hover:border-rose-950 text-rose-400 rounded-xl transition-all cursor-pointer"
          >
            <LogOut size={16} />
          </button>
        )}

        {/* Footer info or minimal action */}
        {!collapsed && (
          <div className="flex items-center justify-between px-2 text-[10px] text-gray-500">
            <span>v1.0.0 Stable</span>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Online</span>
            </div>
          </div>
        )}
      </div>
    </motion.aside>
  );
}
