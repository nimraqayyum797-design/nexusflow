import React, { useState } from "react";
import { motion } from "motion/react";
import {
  Plus,
  Repeat,
  Check,
  TrendingUp,
  Award,
  Calendar,
  Sparkles,
  Trash2,
} from "lucide-react";
import { Habit, Category } from "../types";

interface HabitsViewProps {
  habits: Habit[];
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>;
  accentColor: string;
}

export default function HabitsView({ habits, setHabits, accentColor }: HabitsViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState("");
  const [newFreq, setNewFreq] = useState<"Daily" | "Weekly">("Daily");
  const [newCat, setNewCat] = useState<Category>(Category.Personal);

  const todayStr = new Date().toISOString().split("T")[0];

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newHabit: Habit = {
      id: Math.random().toString(),
      name: newName,
      frequency: newFreq,
      category: newCat,
      streak: 0,
      completedDays: [],
      consistencyScore: 0,
    };

    setHabits((prev) => [...prev, newHabit]);
    setIsAdding(false);
    setNewName("");
  };

  const handleToggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const completedToday = h.completedDays.includes(todayStr);
          let newDays = [...h.completedDays];
          let newStreak = h.streak;

          if (completedToday) {
            newDays = newDays.filter((d) => d !== todayStr);
            newStreak = Math.max(0, newStreak - 1);
          } else {
            newDays.push(todayStr);
            newStreak += 1;
          }

          // Calculate consistency score (percentage of days completed in last 7 days)
          const last7Days = Array.from({ length: 7 }, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - i);
            return d.toISOString().split("T")[0];
          });
          const completedIn7Days = last7Days.filter((day) => newDays.includes(day)).length;
          const consistency = Math.round((completedIn7Days / 7) * 100);

          return {
            ...h,
            completedDays: newDays,
            streak: newStreak,
            consistencyScore: consistency,
            lastCompletedDate: completedToday ? undefined : todayStr,
          };
        }
        return h;
      })
    );
  };

  const handleDeleteHabit = (id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white">Habit Sprints</h2>
          <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
            Lock in long-term success. Every consistent day increments your streak and consistency score.
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-black font-bold text-sm hover:opacity-90 transition-all cursor-pointer"
          style={{ backgroundColor: accentColor }}
        >
          <Plus size={16} strokeWidth={2.5} />
          <span>Add Habit</span>
        </button>
      </div>

      {/* Adding habit drawer */}
      {isAdding && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] max-w-2xl"
        >
          <form onSubmit={handleCreateHabit} className="space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Create Custom Habit</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Read 5 pages of Quran, Walk 30m, Drink 2L water"
                className="bg-[#141414] text-sm text-white border border-[#2C2C2C] rounded-xl px-4 py-2.5 outline-hidden focus:border-gray-500"
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newFreq}
                  onChange={(e) => setNewFreq(e.target.value as any)}
                  className="bg-[#141414] text-sm text-white border border-[#2C2C2C] rounded-xl px-3 py-1 cursor-pointer outline-hidden"
                >
                  <option value="Daily">Daily</option>
                  <option value="Weekly">Weekly</option>
                </select>
                <select
                  value={newCat}
                  onChange={(e) => setNewCat(e.target.value as any)}
                  className="bg-[#141414] text-sm text-white border border-[#2C2C2C] rounded-xl px-3 py-1 cursor-pointer outline-hidden"
                >
                  {Object.values(Category).map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-black font-bold text-xs cursor-pointer hover:opacity-90"
              style={{ backgroundColor: accentColor }}
            >
              Lock Habit
            </button>
          </form>
        </motion.div>
      )}

      {/* Main Grid View of Habits */}
      {habits.length === 0 ? (
        <div className="h-60 border border-dashed border-[#2C2C2C] rounded-3xl flex flex-col items-center justify-center text-center p-6 bg-[#1C1C1C]">
          <Repeat className="text-gray-500 mb-2 animate-spin" style={{ animationDuration: "8s" }} size={24} />
          <p className="text-sm text-gray-500 font-semibold">No habits created. Let's seed your first habit!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {habits.map((habit) => {
            const completedToday = habit.completedDays.includes(todayStr);

            // Compute last 7 days checkoff log
            const daysLog = Array.from({ length: 7 }, (_, i) => {
              const d = new Date();
              d.setDate(d.getDate() - (6 - i));
              const dateStr = d.toISOString().split("T")[0];
              const shortDay = d.toLocaleDateString([], { weekday: "narrow" });
              return { dateStr, shortDay, completed: habit.completedDays.includes(dateStr) };
            });

            return (
              <motion.div
                key={habit.id}
                whileHover={{ y: -2 }}
                className="p-5 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] hover:border-gray-500/20 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="text-[9px] font-bold text-gray-500 bg-[#141414] px-2.5 py-1 rounded uppercase tracking-wider">
                      {habit.category}
                    </span>
                    <h3 className="text-base font-extrabold text-white tracking-wide mt-1.5">{habit.name}</h3>
                  </div>

                  <button
                    onClick={() => handleToggleHabit(habit.id)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center cursor-pointer transition-all ${
                      completedToday ? "bg-emerald-500 text-black shadow-lg" : "bg-[#141414] border border-[#2C2C2C] text-gray-400 hover:text-white"
                    }`}
                  >
                    <Check size={18} strokeWidth={completedToday ? 3.5 : 2} />
                  </button>
                </div>

                {/* Grid checkoff and streaks */}
                <div className="flex items-center justify-between bg-[#141414] border border-[#2C2C2C] p-3 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <Award size={16} className="text-amber-500" />
                    <div className="text-xs">
                      <span className="text-gray-400 block font-medium">STREAK</span>
                      <span className="text-white font-bold">{habit.streak} Days</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <TrendingUp size={16} style={{ color: accentColor }} />
                    <div className="text-xs">
                      <span className="text-gray-400 block font-medium">CONSISTENCY</span>
                      <span className="text-white font-bold">{habit.consistencyScore}%</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteHabit(habit.id)}
                    className="p-2 rounded-lg text-gray-500 hover:text-[#FF5D5D] hover:bg-[#1C1C1C] cursor-pointer transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                {/* 7-Day History Calendar Nodes */}
                <div>
                  <span className="text-[10px] font-extrabold text-gray-500 block uppercase tracking-wider mb-2">
                    Consistency Map (Last 7 Days)
                  </span>
                  <div className="flex items-center justify-between">
                    {daysLog.map((day, idx) => (
                      <div key={idx} className="flex flex-col items-center gap-1.5 flex-1">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs transition-all ${
                            day.completed
                              ? "bg-[#B6FF4D] text-black shadow-md shadow-[#B6FF4D]/10"
                              : "bg-[#141414] border border-[#2C2C2C] text-gray-500"
                          }`}
                          style={{
                            backgroundColor: day.completed ? accentColor : undefined,
                            color: day.completed ? "#000000" : undefined,
                          }}
                        >
                          {day.completed ? <Check size={12} strokeWidth={3} /> : ""}
                        </div>
                        <span className="text-[9px] text-gray-500 font-bold uppercase">{day.shortDay}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
