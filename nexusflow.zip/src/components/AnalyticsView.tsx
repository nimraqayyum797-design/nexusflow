import { useState } from "react";
import { motion } from "motion/react";
import {
  TrendingUp,
  Brain,
  Activity,
  Award,
  Sparkles,
  Loader2,
  List,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  LineChart,
  Line,
  CartesianGrid,
} from "recharts";
import { Task, Habit, DailyPrayer, ProductivityInsights } from "../types";

interface AnalyticsViewProps {
  tasks: Task[];
  habits: Habit[];
  prayers: DailyPrayer[];
  focusTimeToday: number;
  studyTimeToday: number;
  accentColor: string;
}

export default function AnalyticsView({
  tasks,
  habits,
  prayers,
  focusTimeToday,
  studyTimeToday,
  accentColor,
}: AnalyticsViewProps) {
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [insights, setInsights] = useState<ProductivityInsights | null>({
    focusScore: 84,
    scoreJustification: "Nimra's productivity score is highly optimized today. Outstanding task completion speed and sustained focus sprint during early morning peak hours (Fajr hour).",
    productivityDiscovery: "A direct positive correlation of 89% exists between starting deep work within 60 minutes of Fajr and successfully completing high-energy task blocks.",
    faithBalanceInsight: "Your prayer completion (5/5) is serving as an exceptional structural break. This prevents cognitive exhaustion and sustains high performance indexes.",
    immediateAction: "Schedule your most challenging academic assignment (CS paper) during tomorrow's Fajr focus window.",
  });

  const handleAuditInsights = async () => {
    setLoadingInsights(true);
    try {
      const response = await fetch("/api/gemini/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          habits: habits.map((h) => ({ name: h.name, consistency: h.consistencyScore })),
          tasks: {
            completed: tasks.filter((t) => t.status === "completed").length,
            total: tasks.length,
          },
          focusLogs: [focusTimeToday, 45, 90, 60, 30, 120, 110], // mock recent logs
          mood: "Balanced & Alert",
          energyLogs: [
            { hour: "9 AM", level: 90 },
            { hour: "1 PM", level: 60 },
            { hour: "5 PM", level: 75 },
            { hour: "9 PM", level: 40 },
          ],
        }),
      });

      const data = await response.json();
      if (data.insights) {
        setInsights(data.insights);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingInsights(false);
    }
  };

  // Recharts structured dummy metrics
  const focusTrendData = [
    { day: "Mon", focus: 90, target: 120 },
    { day: "Tue", focus: 110, target: 120 },
    { day: "Wed", focus: 45, target: 120 },
    { day: "Thu", focus: focusTimeToday, target: 120 },
    { day: "Fri", focus: 130, target: 120 },
    { day: "Sat", focus: 85, target: 120 },
    { day: "Sun", focus: 60, target: 120 },
  ];

  const tasksData = [
    { name: "Study", Completed: 4, Pending: 2 },
    { name: "Faith", Completed: 3, Pending: 1 },
    { name: "Health", Completed: 1, Pending: 1 },
    { name: "Personal", Completed: 2, Pending: 0 },
    { name: "Work", Completed: 3, Pending: 1 },
  ];

  const studyEnergyCorrelationData = [
    { day: "Mon", study: 3, energy: 85 },
    { day: "Tue", study: 4, energy: 90 },
    { day: "Wed", study: 1.5, energy: 55 },
    { day: "Thu", study: studyTimeToday, energy: 75 },
    { day: "Fri", study: 5, energy: 95 },
    { day: "Sat", study: 2, energy: 60 },
    { day: "Sun", study: 1, energy: 40 },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white">AI Analytics</h2>
          <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
            Discover core correlations between sleep, focus hours, spiritual consistency, and cognitive energy.
          </p>
        </div>

        <button
          onClick={handleAuditInsights}
          disabled={loadingInsights}
          className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-black font-extrabold text-sm hover:opacity-90 transition-all cursor-pointer disabled:opacity-40"
          style={{ backgroundColor: accentColor }}
        >
          {loadingInsights ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              <span>Auditing Metrics...</span>
            </>
          ) : (
            <>
              <Sparkles size={16} />
              <span>Audit Productivity</span>
            </>
          )}
        </button>
      </div>

      {/* AI Performance Audit Insights Cards */}
      {insights && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 rounded-3xl bg-linear-to-r from-[#1C1C1C] via-[#141414] to-[#1C1C1C] border border-[#2C2C2C] grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {/* Audit Score circle */}
          <div className="flex flex-col items-center justify-center text-center p-4 border-b md:border-b-0 md:border-r border-[#2C2C2C]/50 space-y-3">
            <div className="relative flex items-center justify-center w-28 h-28">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="56"
                  cy="56"
                  r="48"
                  className="stroke-neutral-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="56"
                  cy="56"
                  r="48"
                  stroke={accentColor}
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray="301.6"
                  strokeDashoffset={301.6 - (301.6 * insights.focusScore) / 100}
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              <div className="absolute text-3xl font-black text-white font-mono">
                {insights.focusScore}
              </div>
            </div>
            <div>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block">Productivity Quotient</span>
              <p className="text-xs text-[#BDBDBD] font-semibold mt-1.5">{insights.scoreJustification}</p>
            </div>
          </div>

          {/* Productivity Discovery & spiritual balance */}
          <div className="md:col-span-2 space-y-4 flex flex-col justify-between">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5 p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C]">
                <div className="flex items-center gap-2">
                  <Brain size={14} style={{ color: accentColor }} />
                  <span className="text-[10px] font-extrabold text-white uppercase tracking-wider">AI Discovery</span>
                </div>
                <p className="text-xs text-[#BDBDBD] leading-relaxed font-semibold">{insights.productivityDiscovery}</p>
              </div>

              <div className="space-y-1.5 p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C]">
                <div className="flex items-center gap-2">
                  <Award size={14} className="text-emerald-400" />
                  <span className="text-[10px] font-extrabold text-white uppercase tracking-wider">Faith Balance</span>
                </div>
                <p className="text-xs text-[#BDBDBD] leading-relaxed font-semibold">{insights.faithBalanceInsight}</p>
              </div>
            </div>

            {/* Immediate Action plan */}
            <div className="p-4 rounded-2xl bg-[#141414] border border-dashed border-[#2C2C2C] flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-[9px] font-extrabold text-amber-500 block uppercase tracking-wider">IMMEDIATE RECOMMENDED ACTION</span>
                <p className="text-xs text-white font-extrabold">{insights.immediateAction}</p>
              </div>
              <div className="text-xs font-bold text-gray-500 px-3 py-1.5 rounded-lg bg-[#1C1C1C] border border-[#2C2C2C]">
                Flow recommendation
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Main Charts Area Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Focus Trends */}
        <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
            <div className="flex items-center gap-2">
              <TrendingUp size={16} style={{ color: accentColor }} />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Focus Sprints (Minutes/Day)</h3>
            </div>
            <span className="text-[10px] text-gray-500 font-bold">Weekly Map</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={focusTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorFocus" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={accentColor} stopOpacity={0.2} />
                    <stop offset="95%" stopColor={accentColor} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="#525252" fontSize={11} tickLine={false} />
                <YAxis stroke="#525252" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1C1C1C", borderColor: "#2C2C2C" }}
                  labelStyle={{ color: "#BDBDBD", fontWeight: "bold" }}
                />
                <Area type="monotone" dataKey="focus" stroke={accentColor} strokeWidth={2.5} fillOpacity={1} fill="url(#colorFocus)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Task Completion rates */}
        <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
            <div className="flex items-center gap-2">
              <Activity size={16} className="text-blue-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Task Completion Distribution</h3>
            </div>
            <span className="text-[10px] text-gray-500 font-bold">By Category</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tasksData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#525252" fontSize={11} tickLine={false} />
                <YAxis stroke="#525252" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1C1C1C", borderColor: "#2C2C2C" }}
                  labelStyle={{ color: "#BDBDBD" }}
                />
                <Bar dataKey="Completed" stackId="a" fill="#35D07F" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Pending" stackId="a" fill="#FF5D5D" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Study vs Energy */}
        <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
            <div className="flex items-center gap-2">
              <Brain size={16} className="text-purple-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Study Hours vs. Daily Cognitive Energy Indices</h3>
            </div>
            <span className="text-[10px] text-gray-500 font-bold">Sustained Correlation</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={studyEnergyCorrelationData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2C2C2C" vertical={false} />
                <XAxis dataKey="day" stroke="#525252" fontSize={11} tickLine={false} />
                <YAxis stroke="#525252" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1C1C1C", borderColor: "#2C2C2C" }}
                  labelStyle={{ color: "#BDBDBD" }}
                />
                <Line type="monotone" dataKey="study" name="Study (Hours)" stroke="#3B82F6" strokeWidth={3} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="energy" name="Energy Score (%)" stroke="#F59E0B" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
