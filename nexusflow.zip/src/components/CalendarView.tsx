import { useState } from "react";
import { motion } from "motion/react";
import {
  Calendar,
  Clock,
  Plus,
  BookOpen,
  CheckCircle,
  Briefcase,
  ChevronLeft,
  ChevronRight,
  MapPin,
} from "lucide-react";
import { TimelineItem } from "../types";

interface CalendarViewProps {
  timeline: TimelineItem[];
  toggleTimelineItem: (id: string) => void;
  accentColor: string;
}

export default function CalendarView({
  timeline,
  toggleTimelineItem,
  accentColor,
}: CalendarViewProps) {
  const [selectedDay, setSelectedDay] = useState(23); // Default matches today July 23, 2026

  const daysInMonth = 31;
  const startingDayOfWeek = 3; // Wednesday is Jul 1, 2026, so Thursday is 2nd... let's align nicely.

  // Scheduled markers for specific days of July 2026
  const eventsMap: { [key: number]: { title: string; type: string }[] } = {
    10: [{ title: "Fajr Study Hackathon", type: "Study" }],
    15: [{ title: "Corporate Finance Midterm", type: "Exam" }],
    23: [
      { title: "Fajr Study Session", type: "Study" },
      { title: "Corporate Finance Project", type: "Work" },
      { title: "Sprints Group Meeting", type: "Work" },
    ],
    28: [{ title: "AI Term Paper Due", type: "Exam" }],
    31: [{ title: "Monthly Flow Audit with AI", type: "Strategy" }],
  };

  const handleNextMonth = () => {
    // Readonly/visual indicator
  };

  const handlePrevMonth = () => {
    // Readonly/visual indicator
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white">Smart Calendar</h2>
        <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
          Visual monthly dashboard containing academic exam milestones, classes, and daily deep work sessions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid card */}
        <div className="lg:col-span-2 bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3 mb-2">
            <div className="flex items-center gap-2">
              <Calendar className="text-blue-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">July 2026</h3>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handlePrevMonth}
                className="p-1.5 rounded-lg border border-[#2C2C2C] hover:bg-[#141414] text-gray-400 hover:text-white cursor-pointer"
              >
                <ChevronLeft size={14} />
              </button>
              <button
                onClick={handleNextMonth}
                className="p-1.5 rounded-lg border border-[#2C2C2C] hover:bg-[#141414] text-gray-400 hover:text-white cursor-pointer"
              >
                <ChevronRight size={14} />
              </button>
            </div>
          </div>

          {/* Days of week headers */}
          <div className="grid grid-cols-7 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest pb-2">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Monthly grid cells */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty slots for starting week days offset */}
            {Array.from({ length: startingDayOfWeek }).map((_, idx) => (
              <div key={`empty-${idx}`} className="aspect-square bg-transparent"></div>
            ))}

            {/* Days list */}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const dayNum = idx + 1;
              const isSelected = selectedDay === dayNum;
              const isToday = dayNum === 23; // Today is July 23, 2026
              const hasEvents = eventsMap[dayNum] !== undefined;

              return (
                <div
                  key={`day-${dayNum}`}
                  onClick={() => setSelectedDay(dayNum)}
                  className={`aspect-square rounded-2xl flex flex-col justify-between p-2 cursor-pointer transition-all border relative ${
                    isSelected
                      ? "bg-[#2C2C2C]"
                      : "bg-[#141414]/30 hover:bg-[#141414] hover:border-gray-500/10"
                  }`}
                  style={{
                    borderColor: isSelected ? accentColor : isToday ? accentColor : "#2C2C2C",
                  }}
                >
                  <span className={`text-xs font-bold ${isToday ? "text-white" : "text-[#BDBDBD]"}`}>
                    {dayNum}
                  </span>

                  {/* Indicator for day with events */}
                  {hasEvents && (
                    <div className="flex justify-center gap-1">
                      <div
                        className="w-1.5 h-1.5 rounded-full animate-pulse"
                        style={{ backgroundColor: accentColor }}
                      ></div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar Schedule detail card */}
        <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3 mb-2">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Schedule: Jul {selectedDay}, 2026
              </h3>
              <span className="text-xs text-gray-500 font-semibold">
                {eventsMap[selectedDay] ? `${eventsMap[selectedDay].length} Items` : "No Events"}
              </span>
            </div>

            {/* Events logs container */}
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {selectedDay === 23 ? (
                /* Load live editable Timeline list for today */
                timeline.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => toggleTimelineItem(item.id)}
                    className="p-3 rounded-2xl bg-[#141414] border border-[#2C2C2C] flex items-center justify-between cursor-pointer hover:border-gray-500/10 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${
                          item.completed ? "bg-emerald-500 border-emerald-500 text-black" : "border-[#2C2C2C]"
                        }`}
                      >
                        {item.completed && <CheckCircle size={10} className="text-black" strokeWidth={3.5} />}
                      </div>
                      <div>
                        <span className={`text-xs font-bold block ${item.completed ? "text-gray-500 line-through font-medium" : "text-white"}`}>
                          {item.title}
                        </span>
                        <span className="text-[9px] text-gray-500 font-bold uppercase tracking-wider flex items-center gap-1 mt-0.5">
                          <Clock size={10} />
                          {item.time}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-[9px] px-2 py-0.5 rounded uppercase font-extrabold ${
                        item.type === "Prayer" ? "bg-emerald-500/10 text-emerald-400" : "bg-blue-500/10 text-blue-400"
                      }`}
                    >
                      {item.type}
                    </span>
                  </div>
                ))
              ) : eventsMap[selectedDay] ? (
                /* Static scheduled items for selected specific day */
                eventsMap[selectedDay].map((ev, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-[#141414] border border-[#2C2C2C] flex flex-col gap-2"
                  >
                    <span className="text-xs font-bold text-white block">{ev.title}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-bold uppercase text-gray-500 bg-[#1C1C1C] px-2 py-0.5 rounded border border-[#2C2C2C]">
                        {ev.type}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                /* Empty placeholder state */
                <div className="py-12 flex flex-col items-center justify-center text-center text-gray-500 space-y-2">
                  <Clock size={20} />
                  <p className="text-[11px] font-semibold">Workspace completely clear for study rest.</p>
                </div>
              )}
            </div>
          </div>

          <button className="w-full py-3 rounded-2xl bg-[#141414] border border-[#2C2C2C] text-xs font-extrabold text-[#BDBDBD] hover:text-white cursor-pointer transition-all flex items-center justify-center gap-2 mt-4">
            <Plus size={14} />
            <span>Lock Schedule Item</span>
          </button>
        </div>
      </div>
    </div>
  );
}
