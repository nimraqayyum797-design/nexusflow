import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Compass,
  CheckCircle2,
  BookOpen,
  Plus,
  Moon,
  Award,
  ChevronRight,
  Heart,
  Volume2,
  Sparkles,
} from "lucide-react";
import { DailyPrayer, DhikrCounter } from "../types";

interface IslamicViewProps {
  prayers: DailyPrayer[];
  togglePrayer: (id: string) => void;
  accentColor: string;
}

export default function IslamicView({ prayers, togglePrayer, accentColor }: IslamicViewProps) {
  // Quran Tracker local state
  const [qPagesRead, setQPagesRead] = useState(4);
  const [qPagesTarget, setQPagesTarget] = useState(10);
  const [qStreak, setQStreak] = useState(12);

  // Dhikr Counter list state
  const [dhikrList, setDhikrList] = useState<DhikrCounter[]>([
    { id: "1", phrase: "SubhanAllah", meaning: "Glory be to Allah", count: 12, target: 33 },
    { id: "2", phrase: "Alhamdulillah", meaning: "Praise be to Allah", count: 24, target: 33 },
    { id: "3", phrase: "Allahu Akbar", meaning: "Allah is the Greatest", count: 9, target: 33 },
    { id: "4", phrase: "Astaghfirullah", meaning: "I seek forgiveness from Allah", count: 33, target: 100 },
  ]);

  // Daily Dua item
  const dailyDua = {
    arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا",
    translation: "O Allah, I ask You for beneficial knowledge, wholesome sustenance, and deeds that are accepted.",
    meaning: "Recited after Fajr to set a high spiritual, academic, and professional intention for the day's flow.",
  };

  const completedPrayers = prayers.filter((p) => p.completed).length;

  const handleIncrementDhikr = (id: string) => {
    setDhikrList((prev) =>
      prev.map((d) => (d.id === id ? { ...d, count: d.count + 1 } : d))
    );
  };

  const handleResetDhikr = (id: string) => {
    setDhikrList((prev) =>
      prev.map((d) => (d.id === id ? { ...d, count: 0 } : d))
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white">Islamic Companion</h2>
        <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
          Infuse your daily tasks with spiritual barakah. Align your focus sprints around your Salah.
        </p>
      </div>

      {/* Main Grid: Salah and Quran */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Salah Tracking */}
        <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
            <div className="flex items-center gap-2.5">
              <Compass className="text-emerald-400 animate-spin" style={{ animationDuration: "12s" }} size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Salah Tracker</h3>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              {completedPrayers}/5 COMPLETED
            </span>
          </div>

          <div className="space-y-3">
            {prayers.map((prayer) => (
              <div
                key={prayer.id}
                onClick={() => togglePrayer(prayer.id)}
                className="p-3.5 rounded-2xl bg-[#141414] border border-[#2C2C2C] hover:border-emerald-500/30 cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                      prayer.completed
                        ? "bg-emerald-500 border-emerald-500 text-black"
                        : "border-[#2C2C2C] group-hover:border-[#BDBDBD]"
                    }`}
                  >
                    {prayer.completed && <CheckCircle2 size={12} className="text-black" strokeWidth={3.5} />}
                  </div>
                  <span className={`text-sm font-bold ${prayer.completed ? "text-gray-500 line-through font-medium" : "text-white"}`}>
                    {prayer.name}
                  </span>
                </div>
                <span className="text-xs text-gray-500 font-bold">{prayer.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quran Reading Goals */}
        <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
              <div className="flex items-center gap-2.5">
                <BookOpen className="text-blue-400" size={18} />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Quran Tracker</h3>
              </div>
              <div className="flex items-center gap-1.5 text-amber-500">
                <Award size={14} />
                <span className="text-xs font-bold">{qStreak} day streak</span>
              </div>
            </div>

            <p className="text-xs text-[#BDBDBD]">
              Read and contemplate the Holy Book daily. Set a target of pages and maintain consistency.
            </p>

            <div className="space-y-4 pt-2">
              <div>
                <div className="flex justify-between text-xs font-bold text-[#BDBDBD] mb-1">
                  <span>Pages Read Today</span>
                  <span>
                    {qPagesRead}/{qPagesTarget} pages
                  </span>
                </div>
                <div className="w-full bg-[#141414] border border-[#2C2C2C] h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.min((qPagesRead / qPagesTarget) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Adjust counter */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#141414] border border-[#2C2C2C]">
                <button
                  onClick={() => setQPagesRead(Math.max(0, qPagesRead - 1))}
                  className="px-3 py-1.5 rounded-lg border border-[#2C2C2C] text-xs font-bold text-gray-400 hover:text-white"
                >
                  -1 Page
                </button>
                <span className="text-sm font-extrabold text-white">{qPagesRead} Read</span>
                <button
                  onClick={() => setQPagesRead(qPagesRead + 1)}
                  className="px-3 py-1.5 rounded-lg border border-[#2C2C2C] text-xs font-bold text-gray-400 hover:text-white"
                >
                  +1 Page
                </button>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-gray-500 font-semibold leading-relaxed border-t border-[#2C2C2C]/50 pt-3">
            📖 "And the Quran is a guide and mercy for the believers." (17:82)
          </div>
        </div>

        {/* Daily Duas and Intentions */}
        <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl flex flex-col justify-between space-y-4">
          <div className="space-y-3.5">
            <div className="flex items-center gap-2.5 border-b border-[#2C2C2C] pb-3">
              <Heart className="text-purple-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Daily Intention Dua</h3>
            </div>

            {/* Arabic Script */}
            <div className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] text-center space-y-2">
              <span className="text-xl font-bold block text-white leading-loose font-serif">
                {dailyDua.arabic}
              </span>
            </div>

            {/* Translation and context */}
            <div className="space-y-1">
              <span className="text-[10px] font-extrabold text-purple-400 block uppercase tracking-wider">English translation</span>
              <p className="text-xs font-semibold text-[#BDBDBD] leading-relaxed italic">
                "{dailyDua.translation}"
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-extrabold text-gray-500 block uppercase tracking-wider">PRODUCTIVITY Context</span>
              <p className="text-[11px] text-gray-500 leading-relaxed font-medium">
                {dailyDua.meaning}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Tally Dhikr Counter segment */}
      <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl">
        <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <Moon className="text-amber-400" size={18} />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Interactive Dhikr Tally</h3>
          </div>
          <span className="text-xs text-gray-500 font-semibold">Tapping increments tally</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {dhikrList.map((dhikr) => {
            const progressRatio = Math.min((dhikr.count / dhikr.target) * 100, 100);
            return (
              <div
                key={dhikr.id}
                className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] hover:border-gray-500/20 transition-all flex flex-col justify-between h-44 group cursor-pointer"
                onClick={() => handleIncrementDhikr(dhikr.id)}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-base font-extrabold text-white tracking-wide">{dhikr.phrase}</h4>
                    <span className="text-[10px] text-gray-500 block font-semibold">{dhikr.meaning}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleResetDhikr(dhikr.id);
                    }}
                    className="p-1.5 rounded bg-[#1C1C1C] border border-[#2C2C2C] text-[9px] font-extrabold text-gray-500 hover:text-white"
                  >
                    Reset
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-end justify-between">
                    <span className="text-xs font-extrabold text-white">{dhikr.count} / {dhikr.target}</span>
                    <span className="text-[10px] text-gray-500 font-bold uppercase">Tally</span>
                  </div>
                  <div className="w-full bg-[#1C1C1C] h-1.5 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${progressRatio}%`,
                        backgroundColor: progressRatio >= 100 ? "#35D07F" : accentColor,
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Faith-based Productivity Tips */}
      <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-[#2C2C2C]/50 pb-3">Faith & Productivity Tips</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] space-y-2.5">
            <span className="text-xs font-bold text-emerald-400 block uppercase tracking-wider">The Early Hours (Fajr)</span>
            <p className="text-xs text-[#BDBDBD] leading-relaxed font-medium">
              The Prophet Muhammad (PBUH) supplicated: "O Allah, bless my Ummah in their early hours." Schedule your most intensive cognitive work (like programming or writing) immediately after Fajr.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] space-y-2.5">
            <span className="text-xs font-bold text-blue-400 block uppercase tracking-wider">Spiritual Rhythm</span>
            <p className="text-xs text-[#BDBDBD] leading-relaxed font-medium">
              Use Salah times as organic study breaks. Step away from your screens every few hours to make Wudu and pray, reset your cognitive fatigue, and return with peak neural readiness.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] space-y-2.5">
            <span className="text-xs font-bold text-purple-400 block uppercase tracking-wider">Intention (Niyyah)</span>
            <p className="text-xs text-[#BDBDBD] leading-relaxed font-medium">
              Turn your study or work into an act of worship by renewing your intention. Study to benefit humanity, care for your family, and build professional excellence as an act of faith.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
