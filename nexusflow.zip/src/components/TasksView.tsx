import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Plus,
  Sparkles,
  Calendar,
  AlertTriangle,
  Flame,
  CheckSquare,
  Clock,
  Trash2,
  Folder,
  Brain,
  ListFilter,
  Eye,
  Columns,
  List,
  ChevronDown,
  Loader2,
} from "lucide-react";
import { Task, Category, Priority, EnergyLevel, SubTask } from "../types";

interface TasksViewProps {
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  accentColor: string;
}

export default function TasksView({ tasks, setTasks, accentColor }: TasksViewProps) {
  const [viewMode, setViewMode] = useState<"kanban" | "list">("kanban");
  const [energyFilter, setEnergyFilter] = useState<EnergyLevel | "All">("All");
  const [categoryFilter, setCategoryFilter] = useState<Category | "All">("All");

  // State for Create Task Dialog
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newCategory, setNewCategory] = useState<Category>(Category.Personal);
  const [newPriority, setNewPriority] = useState<Priority>(Priority.Medium);
  const [newEnergy, setNewEnergy] = useState<EnergyLevel>(EnergyLevel.Normal);
  const [newMinutes, setNewMinutes] = useState(30);
  const [newDueDate, setNewDueDate] = useState("2026-07-24");

  // State for AI generation loaders
  const [loadingAiMap, setLoadingAiMap] = useState<{ [key: string]: boolean }>({});

  const filteredTasks = tasks.filter((t) => {
    const matchEnergy = energyFilter === "All" || t.energyLevel === energyFilter;
    const matchCategory = categoryFilter === "All" || t.category === categoryFilter;
    return matchEnergy && matchCategory;
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newTask: Task = {
      id: Math.random().toString(),
      title: newTitle,
      description: newDesc,
      category: newCategory,
      priority: newPriority,
      energyLevel: newEnergy,
      estimatedMinutes: newMinutes,
      focusTimeSpent: 0,
      subtasks: [],
      status: "todo",
      dueDate: newDueDate,
    };

    setTasks((prev) => [newTask, ...prev]);
    setIsAdding(false);
    // Reset form
    setNewTitle("");
    setNewDesc("");
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const handleUpdateStatus = (id: string, newStatus: Task["status"]) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updatedSubtasks = t.subtasks.map((s) =>
            s.id === subtaskId ? { ...s, completed: !s.completed } : s
          );
          return { ...t, subtasks: updatedSubtasks };
        }
        return t;
      })
    );
  };

  const handleAIBreakdown = async (taskId: string, title: string, desc: string, energy: EnergyLevel) => {
    setLoadingAiMap((prev) => ({ ...prev, [taskId]: true }));
    try {
      const response = await fetch("/api/gemini/subtasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          taskTitle: title,
          taskDescription: desc,
          energyLevel: energy,
        }),
      });

      const data = await response.json();
      if (data.subtasks && Array.isArray(data.subtasks)) {
        const subtasksWithId: SubTask[] = data.subtasks.map((sub: any) => ({
          id: Math.random().toString(),
          title: sub.title,
          completed: false,
          estimatedMinutes: sub.estimatedMinutes,
        }));

        setTasks((prev) =>
          prev.map((t) => (t.id === taskId ? { ...t, subtasks: subtasksWithId } : t))
        );
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAiMap((prev) => ({ ...prev, [taskId]: false }));
    }
  };

  const taskColumns: { id: Task["status"]; label: string; bg: string }[] = [
    { id: "todo", label: "To Do", bg: "bg-neutral-800/20" },
    { id: "in_progress", label: "In Progress", bg: "bg-blue-500/5" },
    { id: "completed", label: "Completed", bg: "bg-emerald-500/5" },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white">Smart Task Hub</h2>
          <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
            Match your active work sprints to your physical energy levels. Break down hard tasks with AI.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* View Switchers */}
          <div className="flex items-center bg-[#1C1C1C] border border-[#2C2C2C] rounded-2xl p-1">
            <button
              onClick={() => setViewMode("kanban")}
              className={`p-2.5 rounded-xl cursor-pointer ${
                viewMode === "kanban" ? "bg-[#2C2C2C] text-white font-bold" : "text-gray-400 hover:text-white"
              }`}
            >
              <Columns size={16} />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2.5 rounded-xl cursor-pointer ${
                viewMode === "list" ? "bg-[#2C2C2C] text-white font-bold" : "text-gray-400 hover:text-white"
              }`}
            >
              <List size={16} />
            </button>
          </div>

          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-black font-bold text-sm hover:opacity-90 transition-all cursor-pointer"
            style={{ backgroundColor: accentColor }}
          >
            <Plus size={16} strokeWidth={2.5} />
            <span>Create Task</span>
          </button>
        </div>
      </div>

      {/* Filter and Sorting bar */}
      <div className="flex flex-wrap items-center gap-4 bg-[#1C1C1C] border border-[#2C2C2C] p-4 rounded-2xl">
        <div className="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-wider shrink-0">
          <ListFilter size={14} />
          <span>Quick Filters:</span>
        </div>

        {/* Energy Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-400 font-semibold">Energy Level:</span>
          <select
            value={energyFilter}
            onChange={(e) => setEnergyFilter(e.target.value as any)}
            className="bg-[#141414] text-xs text-white border border-[#2C2C2C] rounded-xl px-3 py-1.5 font-bold outline-hidden cursor-pointer"
          >
            <option value="All">All Energy Levels</option>
            <option value="High">🔥 High Energy</option>
            <option value="Normal">⚡ Normal Energy</option>
            <option value="Low">💤 Low Energy</option>
          </select>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-400 font-semibold">Category:</span>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as any)}
            className="bg-[#141414] text-xs text-white border border-[#2C2C2C] rounded-xl px-3 py-1.5 font-bold outline-hidden cursor-pointer"
          >
            <option value="All">All Categories</option>
            {Object.values(Category).map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Active counter indicator */}
        <div className="ml-auto text-xs font-bold text-[#BDBDBD]">
          Showing {filteredTasks.length} tasks
        </div>
      </div>

      {/* Kanban View Board */}
      {viewMode === "kanban" ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {taskColumns.map((col) => {
            const columnTasks = filteredTasks.filter((t) => t.status === col.id);
            return (
              <div key={col.id} className={`rounded-3xl p-5 border border-[#2C2C2C] ${col.bg} flex flex-col min-h-[450px]`}>
                {/* Column Title Header */}
                <div className="flex items-center justify-between border-b border-[#2C2C2C]/50 pb-3 mb-4">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm font-extrabold text-white">{col.label}</span>
                    <span className="text-xs font-bold text-gray-500 bg-[#1C1C1C] border border-[#2C2C2C] px-2 py-0.5 rounded-md">
                      {columnTasks.length}
                    </span>
                  </div>
                </div>

                {/* Column Cards scrollable area */}
                <div className="flex-1 space-y-4 overflow-y-auto">
                  {columnTasks.length === 0 ? (
                    <div className="h-40 border border-dashed border-[#2C2C2C] rounded-2xl flex flex-col items-center justify-center text-center p-4">
                      <span className="text-xs text-gray-500 font-semibold">No tasks here</span>
                    </div>
                  ) : (
                    columnTasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        accentColor={accentColor}
                        onUpdateStatus={handleUpdateStatus}
                        onDelete={handleDeleteTask}
                        onAIBreakdown={handleAIBreakdown}
                        onToggleSubtask={handleToggleSubtask}
                        isAiLoading={loadingAiMap[task.id]}
                      />
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View Mode */
        <div className="space-y-3">
          {filteredTasks.length === 0 ? (
            <div className="h-60 border border-dashed border-[#2C2C2C] rounded-3xl flex flex-col items-center justify-center text-center p-6 bg-[#1C1C1C]">
              <p className="text-sm text-gray-500 font-semibold">No tasks matching filters found.</p>
            </div>
          ) : (
            filteredTasks.map((task) => (
              <div
                key={task.id}
                className="p-4 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] flex flex-col md:flex-row md:items-center justify-between gap-4 group"
              >
                <div className="flex items-center gap-3.5">
                  <input
                    type="checkbox"
                    checked={task.status === "completed"}
                    onChange={() => handleUpdateStatus(task.id, task.status === "completed" ? "todo" : "completed")}
                    className="w-5 h-5 accent-[#B6FF4D] cursor-pointer"
                  />
                  <div>
                    <h4 className={`text-sm font-extrabold text-white ${task.status === "completed" && "line-through text-gray-500"}`}>
                      {task.title}
                    </h4>
                    <p className="text-xs text-gray-500 mt-1">{task.description}</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-[#141414] border border-[#2C2C2C] px-2 py-1 rounded text-gray-400">
                    {task.category}
                  </span>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded ${
                      task.priority === Priority.High
                        ? "bg-red-500/10 text-red-400"
                        : task.priority === Priority.Medium
                        ? "bg-amber-500/10 text-amber-400"
                        : "bg-blue-500/10 text-blue-400"
                    }`}
                  >
                    {task.priority} Priority
                  </span>
                  <span className="text-xs font-bold text-gray-500 flex items-center gap-1.5 ml-2">
                    <Clock size={12} />
                    {task.estimatedMinutes}m
                  </span>
                  <button
                    onClick={() => handleDeleteTask(task.id)}
                    className="p-1.5 rounded-lg text-gray-500 hover:text-[#FF5D5D] hover:bg-[#141414] transition-all ml-4 opacity-0 group-hover:opacity-100 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add Task Modal overlay dialog */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#1C1C1C] border border-[#2C2C2C] rounded-3xl w-full max-w-xl p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
                <h3 className="text-lg font-bold text-white">Create New Task</h3>
                <button
                  onClick={() => setIsAdding(false)}
                  className="text-gray-400 hover:text-white font-bold text-xs"
                >
                  Close
                </button>
              </div>

              <form onSubmit={handleCreateTask} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Task Title *</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Brainstorm study roadmap with AI"
                    className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Description</label>
                  <textarea
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="Provide details or instructions for this sprint block..."
                    className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden h-20 resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Category</label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as any)}
                      className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden cursor-pointer"
                    >
                      {Object.values(Category).map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Energy Demand</label>
                    <select
                      value={newEnergy}
                      onChange={(e) => setNewEnergy(e.target.value as any)}
                      className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden cursor-pointer"
                    >
                      <option value={EnergyLevel.High}>🔥 High Energy</option>
                      <option value={EnergyLevel.Normal}>⚡ Normal Energy</option>
                      <option value={EnergyLevel.Low}>💤 Low Energy</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Priority</label>
                    <select
                      value={newPriority}
                      onChange={(e) => setNewPriority(e.target.value as any)}
                      className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden cursor-pointer"
                    >
                      <option value={Priority.High}>High</option>
                      <option value={Priority.Medium}>Medium</option>
                      <option value={Priority.Low}>Low</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Estimated Time (Min)</label>
                    <input
                      type="number"
                      value={newMinutes}
                      onChange={(e) => setNewMinutes(parseInt(e.target.value) || 30)}
                      className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Due Date</label>
                    <input
                      type="date"
                      value={newDueDate}
                      onChange={(e) => setNewDueDate(e.target.value)}
                      className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden cursor-pointer"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl text-black font-extrabold text-sm hover:opacity-95 transition-all cursor-pointer mt-4"
                  style={{ backgroundColor: accentColor }}
                >
                  Create Task
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* Internal helper card for Kanban layout */
interface TaskCardProps {
  key?: string;
  task: Task;
  accentColor: string;
  onUpdateStatus: (id: string, s: Task["status"]) => void;
  onDelete: (id: string) => void;
  onAIBreakdown: (id: string, title: string, desc: string, energy: EnergyLevel) => any;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  isAiLoading?: boolean;
}

function TaskCard({
  task,
  accentColor,
  onUpdateStatus,
  onDelete,
  onAIBreakdown,
  onToggleSubtask,
  isAiLoading,
}: TaskCardProps) {
  const [subtasksCollapsed, setSubtasksCollapsed] = useState(true);

  const completedSubtasks = task.subtasks.filter((s) => s.completed).length;
  const totalSubtasks = task.subtasks.length;

  return (
    <motion.div
      layout
      whileHover={{ y: -2 }}
      className="p-4 rounded-2xl bg-[#1C1C1C] border border-[#2C2C2C] hover:border-gray-500/20 transition-all space-y-3"
    >
      <div className="flex items-start justify-between">
        <span className="text-[9px] font-bold text-gray-500 bg-[#141414] border border-[#2C2C2C] px-2 py-0.5 rounded uppercase tracking-wider">
          {task.category}
        </span>

        <div className="flex items-center gap-1">
          <span
            className={`text-[8px] font-bold px-1.5 py-0.5 rounded uppercase ${
              task.priority === Priority.High
                ? "bg-red-500/10 text-red-400"
                : task.priority === Priority.Medium
                ? "bg-amber-500/10 text-amber-400"
                : "bg-blue-500/10 text-blue-400"
            }`}
          >
            {task.priority}
          </span>
          <button
            onClick={() => onDelete(task.id)}
            className="p-1 rounded text-gray-500 hover:text-[#FF5D5D] transition-colors cursor-pointer"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>

      <div>
        <h4 className="text-sm font-bold text-white tracking-wide">{task.title}</h4>
        {task.description && <p className="text-xs text-gray-500 mt-1 line-clamp-2">{task.description}</p>}
      </div>

      <div className="flex flex-wrap items-center justify-between text-[11px] text-gray-500 pt-1 border-t border-[#2C2C2C]/30">
        <div className="flex items-center gap-1 font-semibold text-gray-400">
          <span>{task.energyLevel === EnergyLevel.High ? "🔥 High" : task.energyLevel === EnergyLevel.Normal ? "⚡ Normal" : "💤 Low"}</span>
        </div>
        <div className="flex items-center gap-1">
          <Clock size={11} />
          <span>{task.estimatedMinutes}m</span>
        </div>
      </div>

      {/* AI Breakdown Subtasks Section */}
      {task.subtasks && task.subtasks.length > 0 ? (
        <div className="pt-2 border-t border-[#2C2C2C]/30">
          <button
            onClick={() => setSubtasksCollapsed(!subtasksCollapsed)}
            className="flex items-center justify-between w-full text-xs font-bold text-gray-400 hover:text-white cursor-pointer"
          >
            <span>
              Subtasks ({completedSubtasks}/{totalSubtasks})
            </span>
            <ChevronDown size={14} className={`transform transition-transform ${subtasksCollapsed ? "" : "rotate-180"}`} />
          </button>

          {!subtasksCollapsed && (
            <div className="space-y-2.5 mt-2.5">
              {task.subtasks.map((sub) => (
                <div key={sub.id} className="flex items-center gap-2 text-xs bg-[#141414] border border-[#2C2C2C]/50 p-2 rounded-xl">
                  <input
                    type="checkbox"
                    checked={sub.completed}
                    onChange={() => onToggleSubtask(task.id, sub.id)}
                    className="accent-[#B6FF4D] w-3.5 h-3.5 cursor-pointer"
                  />
                  <span className={`text-xs ${sub.completed ? "line-through text-gray-500 font-medium" : "text-white font-semibold"}`}>
                    {sub.title}
                  </span>
                  {sub.estimatedMinutes && (
                    <span className="text-[10px] text-gray-500 ml-auto">{sub.estimatedMinutes}m</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Break down with AI button */
        <button
          onClick={() => onAIBreakdown(task.id, task.title, task.description, task.energyLevel)}
          disabled={isAiLoading}
          className="w-full flex items-center justify-center gap-2 p-2 rounded-xl bg-linear-to-r from-amber-500/10 to-purple-500/10 border border-[#2C2C2C] text-xs font-bold text-[#BDBDBD] hover:text-white cursor-pointer hover:border-gray-500/30 transition-all disabled:opacity-50"
        >
          {isAiLoading ? (
            <>
              <Loader2 size={12} className="animate-spin text-[#B6FF4D]" />
              <span>Analyzing Task...</span>
            </>
          ) : (
            <>
              <Sparkles size={12} style={{ color: accentColor }} />
              <span>AI Task Decomposer</span>
            </>
          )}
        </button>
      )}

      {/* Quick Move column state links */}
      <div className="flex gap-1.5 pt-2 border-t border-[#2C2C2C]/30 text-[9px] font-extrabold uppercase tracking-wider">
        {task.status !== "todo" && (
          <button
            onClick={() => onUpdateStatus(task.id, "todo")}
            className="flex-1 py-1 rounded bg-[#141414] text-gray-400 hover:text-white cursor-pointer text-center"
          >
            Todo
          </button>
        )}
        {task.status !== "in_progress" && (
          <button
            onClick={() => onUpdateStatus(task.id, "in_progress")}
            className="flex-1 py-1 rounded bg-[#141414] text-gray-400 hover:text-white cursor-pointer text-center"
          >
            In Progress
          </button>
        )}
        {task.status !== "completed" && (
          <button
            onClick={() => onUpdateStatus(task.id, "completed")}
            className="flex-1 py-1 rounded bg-[#141414] text-gray-400 hover:text-white cursor-pointer text-center"
          >
            Done
          </button>
        )}
      </div>
    </motion.div>
  );
}
