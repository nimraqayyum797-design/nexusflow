import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Play,
  Pause,
  RotateCcw,
  Zap,
  Music,
  TreePine,
  Coffee,
  CheckCircle,
  AlertCircle,
  Volume2,
  Tv,
} from "lucide-react";

interface FocusViewProps {
  focusTimeToday: number;
  setFocusTimeToday: (val: number) => void;
  accentColor: string;
}

export default function FocusView({
  focusTimeToday,
  setFocusTimeToday,
  accentColor,
}: FocusViewProps) {
  // Timer states
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 mins in seconds
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [pomodorosToday, setPomodorosToday] = useState(2); // Mock some starting trees

  // Sound States
  const [activeSound, setActiveSound] = useState<string | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            // Timer finished!
            setIsRunning(false);
            if (timerRef.current) clearInterval(timerRef.current);

            if (!isBreak) {
              // Work Pomodoro completed
              setFocusTimeToday(focusTimeToday + 25);
              setPomodorosToday((p) => p + 1);
              setIsBreak(true);
              return 5 * 60; // 5 min break
            } else {
              // Break finished
              setIsBreak(false);
              return 25 * 60; // 25 min work
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, isBreak, focusTimeToday]);

  const handleStartPause = () => {
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsBreak(false);
    setTimeLeft(25 * 60);
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rSecs = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${rSecs.toString().padStart(2, "0")}`;
  };

  // Sound list
  const ambientSounds = [
    { id: "lofi", name: "Cyberpunk Lofi", waveColor: "#F59E0B" },
    { id: "rain", name: "Tokyo Rain", waveColor: "#3B82F6" },
    { id: "forest", name: "Deep Forest", waveColor: "#10B981" },
    { id: "cafe", name: "Paris Cafe", waveColor: "#EC4899" },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Pomodoro Focus Dial */}
      <div className="lg:col-span-2 bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl flex flex-col justify-between min-h-[400px]">
        <div>
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3 mb-6">
            <div className="flex items-center gap-2">
              <Zap className="text-amber-400 animate-pulse" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Focus Sprinter</h3>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                isBreak ? "bg-blue-500/10 text-blue-400" : "bg-amber-500/10 text-amber-400"
              }`}
            >
              {isBreak ? "Break Mode" : "Deep Work Sprint"}
            </span>
          </div>

          {/* Time digits */}
          <div className="text-center py-8 space-y-2">
            <span className="text-7xl md:text-8xl font-black text-white tracking-tighter select-none font-mono">
              {formatTime(timeLeft)}
            </span>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">
              {isBreak ? "Take a breath. Walk around. Rest." : "Focus on your selected High Energy task."}
            </p>
          </div>
        </div>

        {/* Dial Controls */}
        <div className="flex items-center justify-center gap-4 mt-4 border-t border-[#2C2C2C]/50 pt-6">
          <button
            onClick={handleReset}
            className="w-12 h-12 rounded-2xl bg-[#141414] border border-[#2C2C2C] text-gray-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
            title="Reset focus clock"
          >
            <RotateCcw size={16} />
          </button>

          <button
            onClick={handleStartPause}
            className="px-8 py-3.5 rounded-2xl text-black font-extrabold text-sm hover:opacity-95 transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#B6FF4D]/5"
            style={{ backgroundColor: accentColor }}
          >
            {isRunning ? <Pause size={16} fill="black" /> : <Play size={16} fill="black" />}
            <span>{isRunning ? "Pause Session" : "Start Focus"}</span>
          </button>
        </div>
      </div>

      {/* Gamified Focus Forest Visualizer */}
      <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl flex flex-col justify-between h-[400px]">
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
            <div className="flex items-center gap-2">
              <TreePine className="text-emerald-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Your Focus Forest</h3>
            </div>
            <span className="text-xs font-bold text-emerald-400">
              {pomodorosToday} trees planted
            </span>
          </div>

          <p className="text-xs text-[#BDBDBD]">
            Every completed 25-minute Pomodoro plants a tree. Stay focused to build a beautiful ecosystem today.
          </p>

          {/* Forest grid tree cells */}
          <div className="grid grid-cols-4 gap-3 pt-2">
            {Array.from({ length: 12 }).map((_, idx) => {
              const hasTree = idx < pomodorosToday;
              return (
                <div
                  key={idx}
                  className={`aspect-square rounded-2xl flex items-center justify-center transition-all ${
                    hasTree
                      ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                      : "bg-[#141414] border border-[#2C2C2C] text-gray-700 hover:border-gray-500/10"
                  }`}
                >
                  {hasTree ? (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 100 }}
                    >
                      <TreePine size={24} />
                    </motion.div>
                  ) : (
                    <span className="text-[10px] font-bold text-gray-800">{idx + 1}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">
          🌴 Daily forest resets at midnight. Seed your focus today.
        </div>
      </div>

      {/* Synthesizer Waveform Soundscape Selector */}
      <div className="lg:col-span-3 bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl">
        <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Music className="text-purple-400" size={18} />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Ambient Wave Synthesizer</h3>
          </div>
          <span className="text-xs text-gray-500 font-semibold">CORS-resilient neural wave loops</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {ambientSounds.map((sound) => {
            const isActive = activeSound === sound.id;
            return (
              <div
                key={sound.id}
                onClick={() => setActiveSound(isActive ? null : sound.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                  isActive
                    ? "bg-[#141414]"
                    : "bg-[#141414]/30 border-[#2C2C2C] hover:border-[#BDBDBD]/10"
                }`}
                style={{
                  borderColor: isActive ? sound.waveColor : undefined,
                }}
              >
                <div className="space-y-1">
                  <span className="text-xs font-bold text-white block">{sound.name}</span>
                  <span className="text-[10px] text-gray-500 block uppercase font-bold">
                    {isActive ? "ACTIVE & SYNCHRONIZING" : "MUTED"}
                  </span>
                </div>

                {/* Animated Pulsing Wave Bar columns */}
                <div className="flex items-end gap-1 h-8 w-12 justify-center">
                  {Array.from({ length: 4 }).map((_, wIdx) => (
                    <motion.div
                      key={wIdx}
                      animate={
                        isActive
                          ? { height: [8, 24, 12, 32, 8][wIdx % 5] }
                          : { height: 4 }
                      }
                      transition={{
                        repeat: Infinity,
                        duration: 1 + wIdx * 0.25,
                        ease: "easeInOut",
                      }}
                      className="w-1.5 rounded-full"
                      style={{
                        backgroundColor: isActive ? sound.waveColor : "#2C2C2C",
                      }}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
