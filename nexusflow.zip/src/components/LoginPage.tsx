import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Lock, User, Sparkles, Eye, EyeOff, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";
import Logo from "./Logo";

interface LoginPageProps {
  onLogin: (user: { name: string; email: string; role: string }) => void;
  accentColor: string;
  setAccentColor: (color: string) => void;
}

export default function LoginPage({ onLogin, accentColor, setAccentColor }: LoginPageProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState("Productive Creator");
  const [showPassword, setShowPassword] = useState(false);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const presetColors = [
    { name: "Neon Lime", value: "#B6FF4D" },
    { name: "Cyan Spark", value: "#00D8F6" },
    { name: "Emerald", value: "#35D07F" },
    { name: "Classic Blue", value: "#0066FF" },
    { name: "Amber", value: "#F59E0B" },
    { name: "Rose Glow", value: "#EC4899" },
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!email || !password) {
      setError("Please fill in all credentials.");
      return;
    }

    if (password.length < 5) {
      setError("Password must be at least 5 characters.");
      return;
    }

    setIsLoading(true);

    // Simulate standard, premium professional latency
    setTimeout(() => {
      setIsLoading(false);
      // Check if there is an account in local storage or create a mock/standard session
      const savedUsers = JSON.parse(localStorage.getItem("nexusflow_registered_users") || "[]");
      const matchedUser = savedUsers.find((u: any) => u.email.toLowerCase() === email.toLowerCase());

      if (matchedUser) {
        if (matchedUser.password === password) {
          setSuccess(`Welcome back, ${matchedUser.name}!`);
          setTimeout(() => {
            onLogin({ name: matchedUser.name, email: matchedUser.email, role: matchedUser.role });
          }, 600);
        } else {
          setError("Incorrect password. Please try again.");
        }
      } else {
        // Standard Demo Login
        if (email.toLowerCase() === "nimra@nexus.com" || email.toLowerCase() === "nimra@gmail.com") {
          setSuccess("Logging in as Nimra...");
          setTimeout(() => {
            onLogin({ name: "Nimra", email: email, role: "Productive Creator" });
          }, 600);
        } else {
          // If not in database, auto-create for user-friendly flow or ask to sign up
          setError("Account not found. Toggle 'Sign Up' below to register a fresh profile!");
        }
      }
    }, 1200);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!name || !email || !password) {
      setError("Please complete all registration fields.");
      return;
    }

    if (password.length < 5) {
      setError("Password must be at least 5 characters.");
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const savedUsers = JSON.parse(localStorage.getItem("nexusflow_registered_users") || "[]");
      
      if (savedUsers.some((u: any) => u.email.toLowerCase() === email.toLowerCase())) {
        setError("An account with this email already exists.");
        return;
      }

      const newUser = { name, email, password, role };
      savedUsers.push(newUser);
      localStorage.setItem("nexusflow_registered_users", JSON.stringify(savedUsers));

      setSuccess("Account successfully established!");
      setTimeout(() => {
        setIsRegistering(false);
        setPassword("");
      }, 1000);
    }, 1200);
  };

  const triggerQuickLogin = (preset: "nimra" | "guest") => {
    setIsLoading(true);
    setError("");
    setSuccess("");

    setTimeout(() => {
      setIsLoading(false);
      if (preset === "nimra") {
        setSuccess("Signed in as Nimra");
        setTimeout(() => {
          onLogin({ name: "Nimra", email: "nimra@nexus.com", role: "Productive Creator" });
        }, 500);
      } else {
        setSuccess("Signed in as Guest");
        setTimeout(() => {
          onLogin({ name: "Guest User", email: "guest@nexusflow.app", role: "Explorer" });
        }, 500);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col justify-center items-center p-6 relative overflow-hidden select-none">
      {/* Decorative background radial blurs */}
      <div 
        className="absolute top-[-20%] left-[-10%] w-[50rem] h-[50rem] rounded-full blur-[160px] opacity-20 pointer-events-none transition-all duration-1000"
        style={{ backgroundColor: `${accentColor}30` }}
      />
      <div 
        className="absolute bottom-[-20%] right-[-10%] w-[50rem] h-[50rem] rounded-full blur-[160px] opacity-15 pointer-events-none transition-all duration-1000"
        style={{ backgroundColor: "#0066FF20" }}
      />

      {/* Decorative Grid Lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#141414_1px,transparent_1px),linear-gradient(to_bottom,#141414_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-25 pointer-events-none"></div>

      <div className="w-full max-w-md z-10">
        {/* Animated Brand Header */}
        <div className="flex flex-col items-center mb-8 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, type: "spring" }}
            className="mb-4"
          >
            <Logo size={88} showText={false} />
          </motion.div>
          
          <motion.h1
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.5 }}
            className="text-3xl font-black tracking-tight"
          >
            <span className="text-[#00A3FF]">Nexus</span>
            <span className="text-[#35D07F]">Flow</span>
          </motion.h1>

          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-xs text-gray-400 mt-2 max-w-sm"
          >
            Sustain your daily habits, study routines, tasks & spiritual barakah inside one premium cockpit.
          </motion.p>
        </div>

        {/* Card Body */}
        <motion.div
          initial={{ y: 25, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="bg-[#111111]/90 border border-[#222222] rounded-2xl p-6 shadow-2xl backdrop-blur-xl relative"
        >
          {/* Accent Color Configurator inside Login */}
          <div className="mb-6 pb-5 border-b border-[#222222] flex flex-col gap-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-500 flex items-center gap-1">
              <Sparkles size={10} className="text-gray-400" /> Pre-Configure Theme Accent
            </span>
            <div className="flex items-center gap-2.5 mt-1.5 flex-wrap">
              {presetColors.map((color) => (
                <button
                  key={color.value}
                  onClick={() => setAccentColor(color.value)}
                  type="button"
                  title={color.name}
                  className="w-5 h-5 rounded-full border transition-all relative flex items-center justify-center cursor-pointer"
                  style={{ 
                    backgroundColor: color.value,
                    borderColor: accentColor === color.value ? "#FFFFFF" : "transparent",
                    boxShadow: accentColor === color.value ? `0 0 10px ${color.value}` : "none",
                    transform: accentColor === color.value ? "scale(1.15)" : "scale(1)"
                  }}
                >
                  {accentColor === color.value && (
                    <div className="w-1.5 h-1.5 rounded-full bg-[#080808]" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <AnimatePresence mode="wait">
            {!isRegistering ? (
              // LOGIN FORM
              <motion.form
                key="login"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleLogin}
                className="flex flex-col gap-4"
              >
                {/* Email Input */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-3.5 text-gray-500" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. nimra@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-3 pl-11 pr-4 text-sm font-medium outline-none transition-all text-white placeholder-gray-600"
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between items-center">
                    <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                      Security Password
                    </label>
                  </div>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-3.5 text-gray-500" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="Enter security password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-3 pl-11 pr-11 text-sm font-medium outline-none transition-all text-white placeholder-gray-600"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-gray-500 hover:text-white transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {/* Status Banners */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-rose-950/40 border border-rose-850 p-3 rounded-xl flex items-start gap-2.5 text-xs text-rose-300"
                  >
                    <AlertCircle size={14} className="shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </motion.div>
                )}

                {success && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-emerald-950/40 border border-emerald-850 p-3 rounded-xl flex items-start gap-2.5 text-xs text-emerald-300"
                  >
                    <CheckCircle2 size={14} className="shrink-0 mt-0.5" />
                    <span>{success}</span>
                  </motion.div>
                )}

                {/* Submit Action */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 rounded-xl text-black font-extrabold text-sm transition-all relative flex items-center justify-center gap-2 overflow-hidden shadow-lg cursor-pointer hover:brightness-110 disabled:opacity-50"
                  style={{ backgroundColor: accentColor }}
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Enter Workspace</span>
                      <ArrowRight size={16} />
                    </>
                  )}
                </button>
              </motion.form>
            ) : (
              // REGISTRATION FORM
              <motion.form
                key="register"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleRegister}
                className="flex flex-col gap-4"
              >
                {/* Full Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                    Full Name
                  </label>
                  <div className="relative">
                    <User size={16} className="absolute left-3.5 top-3.5 text-gray-500" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Nimra Qayyum"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-3 pl-11 pr-4 text-sm font-medium outline-none transition-all text-white placeholder-gray-600"
                    />
                  </div>
                </div>

                {/* Email */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-3.5 text-gray-500" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. nimra@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-3 pl-11 pr-4 text-sm font-medium outline-none transition-all text-white placeholder-gray-600"
                    />
                  </div>
                </div>

                {/* Security Password */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                    Choose Security Password
                  </label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-3.5 text-gray-500" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="Min. 5 characters"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-3 pl-11 pr-11 text-sm font-medium outline-none transition-all text-white placeholder-gray-600"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-gray-500 hover:text-white transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {/* Custom Role */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                    Workspace Role / Tagline
                  </label>
                  <div className="relative">
                    <Sparkles size={16} className="absolute left-3.5 top-3.5 text-gray-500" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Productive Creator, Tech Architect"
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-3 pl-11 pr-4 text-sm font-medium outline-none transition-all text-white placeholder-gray-600"
                    />
                  </div>
                </div>

                {/* Status Banners */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-rose-950/40 border border-rose-850 p-3 rounded-xl flex items-start gap-2.5 text-xs text-rose-300"
                  >
                    <AlertCircle size={14} className="shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </motion.div>
                )}

                {success && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-emerald-950/40 border border-emerald-850 p-3 rounded-xl flex items-start gap-2.5 text-xs text-emerald-300"
                  >
                    <CheckCircle2 size={14} className="shrink-0 mt-0.5" />
                    <span>{success}</span>
                  </motion.div>
                )}

                {/* Submit Action */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 rounded-xl text-black font-extrabold text-sm transition-all relative flex items-center justify-center gap-2 overflow-hidden shadow-lg cursor-pointer hover:brightness-110 disabled:opacity-50"
                  style={{ backgroundColor: accentColor }}
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Establish Account</span>
                      <ArrowRight size={16} />
                    </>
                  )}
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Toggle Tab Footer */}
          <div className="mt-5 pt-4 border-t border-[#222222] flex justify-center text-xs text-gray-500">
            {!isRegistering ? (
              <span>
                New to NexusFlow?{" "}
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(true);
                    setError("");
                  }}
                  className="font-extrabold text-white hover:underline transition-all cursor-pointer"
                  style={{ color: accentColor }}
                >
                  Create an account
                </button>
              </span>
            ) : (
              <span>
                Already registered?{" "}
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(false);
                    setError("");
                  }}
                  className="font-extrabold text-white hover:underline transition-all cursor-pointer"
                  style={{ color: accentColor }}
                >
                  Sign in
                </button>
              </span>
            )}
          </div>
        </motion.div>

        {/* Quick Demo Pre-sets */}
        <motion.div
          initial={{ y: 25, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="mt-6 flex flex-col items-center gap-3"
        >
          <span className="text-[10px] uppercase font-bold tracking-widest text-gray-600">
            ⚡ Quick Access Portals
          </span>
          <div className="flex gap-4 w-full justify-center">
            <button
              onClick={() => triggerQuickLogin("nimra")}
              disabled={isLoading}
              className="px-4 py-2 bg-[#121212] border border-[#222222] hover:border-gray-600 rounded-xl text-xs text-gray-300 font-semibold transition-all cursor-pointer hover:bg-[#161616]"
            >
              🚀 Nimra's Profile
            </button>
            <button
              onClick={() => triggerQuickLogin("guest")}
              disabled={isLoading}
              className="px-4 py-2 bg-[#121212] border border-[#222222] hover:border-gray-600 rounded-xl text-xs text-gray-400 font-semibold transition-all cursor-pointer hover:bg-[#161616]"
            >
              👤 Guest Workspace
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
