import React, { useState } from "react";
import { motion } from "motion/react";
import {
  Plus,
  BookText,
  Calendar,
  Trash2,
  Folder,
  Tag,
  Search,
} from "lucide-react";
import { Note, Category } from "../types";

interface JournalViewProps {
  notes: Note[];
  setNotes: React.Dispatch<React.SetStateAction<Note[]>>;
  accentColor: string;
}

export default function JournalView({ notes, setNotes, accentColor }: JournalViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newCat, setNewCat] = useState<Category>(Category.Personal);
  const [searchTerm, setSearchTerm] = useState("");

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const newNote: Note = {
      id: Math.random().toString(),
      title: newTitle,
      content: newContent,
      category: newCat,
      updatedAt: new Date().toLocaleDateString([], {
        month: "short",
        day: "numeric",
        year: "numeric",
      }),
    };

    setNotes((prev) => [newNote, ...prev]);
    setIsAdding(false);
    setNewTitle("");
    setNewContent("");
  };

  const handleDeleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const filteredNotes = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white">Notes & Journal</h2>
          <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
            Capture academic summaries, daily reflections, or strategic ideas. Organize with category tags.
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-black font-bold text-sm hover:opacity-90 transition-all cursor-pointer"
          style={{ backgroundColor: accentColor }}
        >
          <Plus size={16} strokeWidth={2.5} />
          <span>Write Note</span>
        </button>
      </div>

      {/* Write Note card drawer */}
      {isAdding && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] max-w-3xl"
        >
          <form onSubmit={handleCreateNote} className="space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Reflect & Log</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase">Note Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Brainstorm study roadmap with AI"
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase">Category</label>
                <select
                  value={newCat}
                  onChange={(e) => setNewCat(e.target.value as any)}
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden cursor-pointer"
                >
                  {Object.values(Category).map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-[#BDBDBD] font-bold uppercase">Content Body</label>
              <textarea
                required
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="Log your thoughts, milestones achieved, active questions, or class notes here..."
                className="w-full h-36 bg-[#141414] border border-[#2C2C2C] rounded-2xl p-4 text-sm text-white focus:outline-hidden resize-none"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-2xl text-black font-extrabold text-xs cursor-pointer hover:opacity-90"
              style={{ backgroundColor: accentColor }}
            >
              Save Notes
            </button>
          </form>
        </motion.div>
      )}

      {/* Search notes bar */}
      <div className="relative max-w-md">
        <Search className="absolute left-4 top-3.5 text-gray-500" size={16} />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search through past reflections..."
          className="w-full bg-[#1C1C1C] border border-[#2C2C2C] rounded-2xl pl-11 pr-4 py-3 text-sm text-white placeholder-gray-500 outline-hidden focus:border-gray-500 transition-colors"
        />
      </div>

      {/* Grid of Note Cards */}
      {filteredNotes.length === 0 ? (
        <div className="h-60 border border-dashed border-[#2C2C2C] rounded-3xl flex flex-col items-center justify-center text-center p-6 bg-[#1C1C1C]">
          <BookText className="text-gray-500 mb-2" size={24} />
          <p className="text-sm text-gray-500 font-semibold">No notes logged yet. Let's start journaling today!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredNotes.map((note) => (
            <motion.div
              key={note.id}
              whileHover={{ y: -2 }}
              className="p-5 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] hover:border-gray-500/20 transition-all flex flex-col justify-between h-56 space-y-4"
            >
              <div>
                <div className="flex items-start justify-between">
                  <span className="text-[9px] font-bold text-gray-500 bg-[#141414] px-2 py-0.5 rounded uppercase tracking-wider">
                    {note.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-gray-500 text-xs font-bold">
                    <Calendar size={12} />
                    <span>{note.updatedAt}</span>
                    <button
                      onClick={() => handleDeleteNote(note.id)}
                      className="p-1 rounded text-gray-500 hover:text-[#FF5D5D] transition-colors cursor-pointer"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                <h3 className="text-base font-extrabold text-white tracking-wide mt-2 line-clamp-1">{note.title}</h3>
                <p className="text-xs text-[#BDBDBD] mt-1.5 leading-relaxed line-clamp-5 font-medium whitespace-pre-line">
                  {note.content}
                </p>
              </div>

              <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider flex items-center gap-1.5 pt-2 border-t border-[#2C2C2C]/30">
                <Tag size={10} />
                <span>Reflection Log</span>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
