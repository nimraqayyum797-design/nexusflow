import React, { useState } from "react";
import { motion } from "motion/react";
import {
  Plus,
  Target,
  CheckCircle2,
  Calendar,
  Sparkles,
  Trash2,
} from "lucide-react";
import { Goal, Category } from "../types";

interface GoalsViewProps {
  goals: Goal[];
  setGoals: React.Dispatch<React.SetStateAction<Goal[]>>;
  accentColor: string;
}

export default function GoalsView({ goals, setGoals, accentColor }: GoalsViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDate, setNewDate] = useState("2026-12-31");
  const [newCat, setNewCat] = useState<Category>(Category.Personal);
  const [milestonesText, setMilestonesText] = useState("");

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    // Split milestones text by comma or newline
    const subgoals = milestonesText
      .split(/[,\n]/)
      .map((item) => item.trim())
      .filter((item) => item.length > 0)
      .map((item) => ({
        id: Math.random().toString(),
        title: item,
        completed: false,
      }));

    const newGoal: Goal = {
      id: Math.random().toString(),
      title: newTitle,
      targetDate: newDate,
      category: newCat,
      progress: 0,
      subGoals: subgoals,
      status: "active",
    };

    setGoals((prev) => [...prev, newGoal]);
    setIsAdding(false);
    setNewTitle("");
    setMilestonesText("");
  };

  const handleToggleSubgoal = (goalId: string, subgoalId: string) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          const updatedSub = g.subGoals.map((sub) =>
            sub.id === subgoalId ? { ...sub, completed: !sub.completed } : sub
          );

          // Recalculate percentage
          const completedCount = updatedSub.filter((s) => s.completed).length;
          const totalCount = updatedSub.length;
          const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

          return {
            ...g,
            subGoals: updatedSub,
            progress: percentage,
            status: percentage === 100 ? "completed" : "active",
          };
        }
        return g;
      })
    );
  };

  const handleDeleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white">Goal Planner</h2>
          <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
            Define high-impact milestones. Break down long-term dreams into small trackable steps.
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-black font-bold text-sm hover:opacity-90 transition-all cursor-pointer"
          style={{ backgroundColor: accentColor }}
        >
          <Plus size={16} strokeWidth={2.5} />
          <span>Lock New Goal</span>
        </button>
      </div>

      {/* Adding Goal form */}
      {isAdding && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] max-w-3xl"
        >
          <form onSubmit={handleCreateGoal} className="space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Set Core Intention</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase">Goal Objective</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Master React 19 & Full Stack Engineering"
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs text-[#BDBDBD] font-bold uppercase">Target Date</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-3 py-2 text-xs text-white cursor-pointer focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-[#BDBDBD] font-bold uppercase">Category</label>
                  <select
                    value={newCat}
                    onChange={(e) => setNewCat(e.target.value as any)}
                    className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-3 py-2 text-xs text-white cursor-pointer focus:outline-hidden"
                  >
                    {Object.values(Category).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-[#BDBDBD] font-bold uppercase">Milestones / Sub-goals (Comma or newline separated)</label>
              <textarea
                value={milestonesText}
                onChange={(e) => setMilestonesText(e.target.value)}
                placeholder="e.g. Build 5 portfolio apps, Read 2 textbooks, Write a summary article"
                className="w-full h-20 bg-[#141414] border border-[#2C2C2C] rounded-2xl p-4 text-sm text-white focus:outline-hidden resize-none"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-2xl text-black font-extrabold text-xs cursor-pointer hover:opacity-90"
              style={{ backgroundColor: accentColor }}
            >
              Lock Core Intention
            </button>
          </form>
        </motion.div>
      )}

      {/* List of Goals */}
      {goals.length === 0 ? (
        <div className="h-60 border border-dashed border-[#2C2C2C] rounded-3xl flex flex-col items-center justify-center text-center p-6 bg-[#1C1C1C]">
          <Target className="text-gray-500 mb-2" size={24} />
          <p className="text-sm text-gray-500 font-semibold">No active goals yet. Let's dream big and seed your first objective!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {goals.map((goal) => (
            <motion.div
              key={goal.id}
              whileHover={{ y: -2 }}
              className="p-5 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between">
                  <span className="text-[9px] font-bold text-gray-500 bg-[#141414] px-2.5 py-1 rounded uppercase tracking-wider">
                    {goal.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-gray-500 text-xs font-bold">
                    <Calendar size={12} />
                    <span>Target: {goal.targetDate}</span>
                    <button
                      onClick={() => handleDeleteGoal(goal.id)}
                      className="p-1 rounded text-gray-500 hover:text-[#FF5D5D] transition-colors cursor-pointer"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                <h3 className="text-base font-extrabold text-white tracking-wide mt-2">{goal.title}</h3>

                {/* Progress bar */}
                <div className="space-y-1.5 mt-3">
                  <div className="flex justify-between text-xs font-bold text-[#BDBDBD]">
                    <span>Intention Completion</span>
                    <span style={{ color: accentColor }}>{goal.progress}%</span>
                  </div>
                  <div className="w-full bg-[#141414] h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${goal.progress}%`,
                        backgroundColor: goal.progress === 100 ? "#35D07F" : accentColor,
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Subgoals checklist list */}
              {goal.subGoals && goal.subGoals.length > 0 && (
                <div className="pt-3 border-t border-[#2C2C2C]/50 space-y-2">
                  <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block mb-1">
                    Core Milestones Required
                  </span>
                  {goal.subGoals.map((sub) => (
                    <div
                      key={sub.id}
                      onClick={() => handleToggleSubgoal(goal.id, sub.id)}
                      className="flex items-center gap-2.5 p-2 rounded-xl bg-[#141414] border border-[#2C2C2C]/50 cursor-pointer hover:border-gray-500/20 transition-all group"
                    >
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${
                          sub.completed
                            ? "bg-emerald-500 border-emerald-500 text-black"
                            : "border-[#2C2C2C]"
                        }`}
                      >
                        {sub.completed && <CheckCircle2 size={10} className="text-black" strokeWidth={3.5} />}
                      </div>
                      <span className={`text-xs ${sub.completed ? "line-through text-gray-500 font-medium" : "text-white font-semibold"}`}>
                        {sub.title}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
