import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles,
  BookOpen,
  Zap,
  BookText,
  Send,
  Loader2,
  Trash2,
  Smile,
  Compass,
} from "lucide-react";
import { AssistantMessage } from "../types";

interface AssistantViewProps {
  chatHistories: { [key: string]: AssistantMessage[] };
  setChatHistories: React.Dispatch<React.SetStateAction<{ [key: string]: AssistantMessage[] }>>;
  accentColor: string;
}

export default function AssistantView({
  chatHistories,
  setChatHistories,
  accentColor,
}: AssistantViewProps) {
  const [activeAssistant, setActiveAssistant] = useState<"coach" | "tutor" | "focus" | "faith">("coach");
  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const assistants = [
    {
      id: "coach",
      name: "AI Life Coach",
      icon: Sparkles,
      color: "#F59E0B",
      placeholder: "Plan my day, break down mental blocks, plan routines, or get motivation...",
      quickPrompts: [
        "Plan my day strategically",
        "How can I overcome procrastination?",
        "Suggest a balanced daily routine",
        "Give me a boost of premium motivation",
      ],
    },
    {
      id: "tutor",
      name: "AI Study Tutor",
      icon: BookOpen,
      color: "#3B82F6",
      placeholder: "Explain a difficult concept, summarize notes, generate study roadmap...",
      quickPrompts: [
        "Explain Quantum Computing like I'm 10",
        "Create a 4-week exam roadmap",
        "Summarize active learning methods",
        "Give me tips for staying alert while studying",
      ],
    },
    {
      id: "focus",
      name: "AI Focus Companion",
      icon: Zap,
      color: "#10B981",
      placeholder: "Block out distractions, design deep work sprints, enter flow states...",
      quickPrompts: [
        "Give me a quick 2-minute focus exercise",
        "How to block dopamine distractions?",
        "Design a 90-minute study sprint block",
        "I feel mentally exhausted. Suggest a break.",
      ],
    },
    {
      id: "faith",
      name: "Islamic Companion",
      icon: BookText,
      color: "#8B5CF6",
      placeholder: "Align daily schedules with spiritual obligations, read tips...",
      quickPrompts: [
        "How to maintain a high faith streak during exams?",
        "Explain the concept of Barakah in productivity",
        "Give me three practical tips for waking up for Fajr",
        "Daily dua for clarity & knowledge",
      ],
    },
  ];

  const selectedAssistant = assistants.find((a) => a.id === activeAssistant)!;
  const activeMessages = chatHistories[activeAssistant] || [];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeMessages]);

  const handleSendMessage = async (textToSend: string) => {
    const text = textToSend.trim();
    if (!text) return;

    setInputValue("");
    const userMessage: AssistantMessage = {
      id: Math.random().toString(),
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedHistory = [...activeMessages, userMessage];

    // Optimistically update UI
    setChatHistories((prev) => ({
      ...prev,
      [activeAssistant]: updatedHistory,
    }));

    setLoading(true);

    try {
      const response = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assistantType: activeAssistant,
          messages: updatedHistory,
        }),
      });

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      const assistantMessage: AssistantMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: data.text || "I was unable to formulate a response. Please check your query.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChatHistories((prev) => ({
        ...prev,
        [activeAssistant]: [...updatedHistory, assistantMessage],
      }));
    } catch (err: any) {
      console.error(err);
      const errorMessage: AssistantMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: `⚠️ Error: ${err.message || "Failed to contact NexusFlow server."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatHistories((prev) => ({
        ...prev,
        [activeAssistant]: [...updatedHistory, errorMessage],
      }));
    } finally {
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    setChatHistories((prev) => ({
      ...prev,
      [activeAssistant]: [],
    }));
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] max-w-7xl mx-auto p-1.5 md:p-4 gap-4">
      {/* Assistants Persona Tabs Selector */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {assistants.map((ast) => {
          const Icon = ast.icon;
          const isSelected = activeAssistant === ast.id;
          return (
            <button
              key={ast.id}
              onClick={() => setActiveAssistant(ast.id as any)}
              className={`flex items-center gap-2.5 p-3.5 rounded-2xl border transition-all cursor-pointer text-left ${
                isSelected
                  ? "bg-[#1C1C1C]"
                  : "bg-transparent border-[#2C2C2C] hover:bg-[#141414] text-gray-400 hover:text-white"
              }`}
              style={{
                borderColor: isSelected ? ast.color : "#2C2C2C",
              }}
            >
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${ast.color}15`, color: ast.color }}
              >
                <Icon size={16} />
              </div>
              <div className="overflow-hidden">
                <span className="text-xs font-bold block text-gray-500 uppercase tracking-wider">PERSONA</span>
                <span className="text-sm font-extrabold text-white truncate block">{ast.name}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Chat Interface */}
      <div className="flex-1 bg-[#1C1C1C] border border-[#2C2C2C] rounded-3xl overflow-hidden flex flex-col relative">
        {/* Chat Header */}
        <div className="p-4 border-b border-[#2C2C2C]/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold"
              style={{ backgroundColor: `${selectedAssistant.color}15`, color: selectedAssistant.color }}
            >
              {<selectedAssistant.icon size={20} />}
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-white">{selectedAssistant.name}</h3>
              <p className="text-[11px] text-gray-400">Powered by Gemini 3.6 Flash</p>
            </div>
          </div>

          {activeMessages.length > 0 && (
            <button
              onClick={handleClearChat}
              className="p-2 rounded-xl hover:bg-[#141414] text-gray-400 hover:text-[#FF5D5D] transition-all cursor-pointer"
              title="Clear active chat history"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>

        {/* Message logs viewport */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[calc(100vh-320px)] md:max-h-[calc(100vh-280px)]">
          {activeMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-6">
              <div
                className="w-16 h-16 rounded-3xl flex items-center justify-center animate-pulse"
                style={{ backgroundColor: `${selectedAssistant.color}10`, color: selectedAssistant.color }}
              >
                {<selectedAssistant.icon size={32} />}
              </div>
              <div className="space-y-2 max-w-lg">
                <h4 className="text-lg font-bold text-white">Ask your {selectedAssistant.name} anything</h4>
                <p className="text-sm text-[#BDBDBD]">
                  Overcome procrastination, seek spiritual clarity, explore academic topics, or map your flow state.
                </p>
              </div>

              {/* Quick Starter Prompts */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-xl mt-4">
                {selectedAssistant.quickPrompts.map((promptText, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(promptText)}
                    className="p-3.5 rounded-2xl bg-[#141414] border border-[#2C2C2C] text-xs text-left font-semibold text-[#BDBDBD] hover:text-white hover:border-[#BDBDBD]/30 cursor-pointer transition-all"
                  >
                    {promptText}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {activeMessages.map((msg) => {
                const isAssistant = msg.role === "assistant";
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isAssistant ? "justify-start" : "justify-end"}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed ${
                        isAssistant
                          ? "bg-[#141414] text-white border border-[#2C2C2C]"
                          : "text-black"
                      }`}
                      style={{
                        backgroundColor: isAssistant ? undefined : accentColor,
                        color: isAssistant ? undefined : "#000000",
                        fontWeight: isAssistant ? 500 : 600,
                      }}
                    >
                      {/* Formatted markdown blocks if present, or clean lines */}
                      <div className="whitespace-pre-line">
                        {msg.content}
                      </div>
                      <span
                        className={`text-[9px] mt-2 block text-right font-semibold ${
                          isAssistant ? "text-gray-500" : "text-black/60"
                        }`}
                      >
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* Loading AI Skeletons */}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-[#141414] border border-[#2C2C2C] max-w-[80%] rounded-2xl p-4 flex items-center gap-3">
                    <Loader2 size={16} className="text-gray-400 animate-spin" />
                    <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider">
                      AI is formulating response...
                    </span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Quick starter list above input bar when activeMessages are present */}
        {activeMessages.length > 0 && !loading && (
          <div className="px-4 py-2 flex gap-2 overflow-x-auto border-t border-[#2C2C2C]/50 bg-[#141414]/40 scrollbar-none">
            {selectedAssistant.quickPrompts.slice(0, 2).map((promptText, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(promptText)}
                className="px-3.5 py-2.5 rounded-full bg-[#1C1C1C] border border-[#2C2C2C] text-[11px] font-bold text-[#BDBDBD] hover:text-white whitespace-nowrap cursor-pointer transition-all"
              >
                {promptText}
              </button>
            ))}
          </div>
        )}

        {/* Input Text Box */}
        <div className="p-4 border-t border-[#2C2C2C]/50 bg-[#141414]/30 flex items-center gap-2.5">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(inputValue);
              }
            }}
            placeholder={selectedAssistant.placeholder}
            className="flex-1 bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-3 text-sm text-white placeholder-gray-500 outline-hidden focus:border-gray-500 transition-colors"
          />
          <button
            onClick={() => handleSendMessage(inputValue)}
            disabled={loading || !inputValue.trim()}
            className="w-11 h-11 rounded-2xl flex items-center justify-center transition-all cursor-pointer disabled:opacity-30 shrink-0"
            style={{
              backgroundColor: inputValue.trim() ? accentColor : "#2C2C2C",
              color: inputValue.trim() ? "#000000" : "#BDBDBD",
            }}
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
