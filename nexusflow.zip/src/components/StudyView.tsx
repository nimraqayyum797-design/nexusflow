import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles,
  BookOpen,
  HelpCircle,
  FolderMinus,
  CheckCircle2,
  Clock,
  ArrowRight,
  BrainCircuit,
  Loader2,
  ChevronLeft,
  ChevronRight,
  RotateCw,
} from "lucide-react";
import { Flashcard, QuizQuestion } from "../types";

interface StudyViewProps {
  accentColor: string;
}

export default function StudyView({ accentColor }: StudyViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<"tutor" | "flashcards" | "quiz" | "tracker">("tutor");

  // AI Concept Explainer state
  const [conceptInput, setConceptInput] = useState("");
  const [explainMode, setExplainMode] = useState<"eli5" | "deep" | "analogies">("eli5");
  const [explanation, setExplanation] = useState("");
  const [explainLoading, setExplainLoading] = useState(false);

  // AI Flashcards state
  const [flashcardTopic, setFlashcardTopic] = useState("");
  const [flashcards, setFlashcards] = useState<Flashcard[]>([
    { id: "1", question: "What is Active Recall?", answer: "A testing-based study technique where you stimulate your memory for a piece of information during learning, strengthening neural connections compared to passive reading." },
    { id: "2", question: "How does the Spaced Repetition method work?", answer: "Increasing the intervals of time between review sessions of a concept to exploit the psychological spacing effect, slowing down the rate of forgetting." }
  ]);
  const [flashcardsLoading, setFlashcardsLoading] = useState(false);
  const [currentCardIdx, setCurrentCardIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // AI Quiz state
  const [quizTopic, setQuizTopic] = useState("");
  const [difficulty, setDifficulty] = useState("Medium");
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [quizLoading, setQuizLoading] = useState(false);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  // Assignment Tracker state
  const [assignments, setAssignments] = useState([
    { id: "1", title: "Artificial Intelligence Term Paper", course: "Computer Science", dueDate: "2026-07-28", completed: false },
    { id: "2", title: "Islamic History Midterm", course: "Humanities", dueDate: "2026-08-02", completed: false },
    { id: "3", title: "Corporate Finance Project", course: "Business Economics", dueDate: "2026-07-31", completed: true },
  ]);
  const [newAssignTitle, setNewAssignTitle] = useState("");
  const [newAssignCourse, setNewAssignCourse] = useState("");
  const [newAssignDue, setNewAssignDue] = useState("2026-07-26");

  // Handle AI Concept Explainer
  const handleExplainConcept = async () => {
    if (!conceptInput.trim()) return;
    setExplainLoading(true);
    setExplanation("");
    try {
      const response = await fetch("/api/gemini/study/explain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ concept: conceptInput, mode: explainMode }),
      });
      const data = await response.json();
      if (data.explanation) {
        setExplanation(data.explanation);
      } else {
        setExplanation("Error: No response generated. Please check your prompt.");
      }
    } catch (e) {
      console.error(e);
      setExplanation("Failed to connect to AI server. Please try again.");
    } finally {
      setExplainLoading(false);
    }
  };

  // Handle AI Flashcard Generator
  const handleGenerateFlashcards = async () => {
    if (!flashcardTopic.trim()) return;
    setFlashcardsLoading(true);
    try {
      const response = await fetch("/api/gemini/study/flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: flashcardTopic }),
      });
      const data = await response.json();
      if (data.flashcards && Array.isArray(data.flashcards)) {
        setFlashcards(data.flashcards);
        setCurrentCardIdx(0);
        setIsFlipped(false);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setFlashcardsLoading(false);
    }
  };

  // Handle AI Quiz Generator
  const handleGenerateQuiz = async () => {
    if (!quizTopic.trim()) return;
    setQuizLoading(true);
    setQuizQuestions([]);
    setCurrentQuestionIdx(0);
    setSelectedAnswers({});
    setQuizSubmitted(false);
    try {
      const response = await fetch("/api/gemini/study/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: quizTopic, difficulty }),
      });
      const data = await response.json();
      if (data.quiz && Array.isArray(data.quiz)) {
        setQuizQuestions(data.quiz);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setQuizLoading(false);
    }
  };

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAssignTitle.trim()) return;
    const newAssign = {
      id: Math.random().toString(),
      title: newAssignTitle,
      course: newAssignCourse || "General Study",
      dueDate: newAssignDue,
      completed: false,
    };
    setAssignments((prev) => [newAssign, ...prev]);
    setNewAssignTitle("");
    setNewAssignCourse("");
  };

  const toggleAssignment = (id: string) => {
    setAssignments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, completed: !a.completed } : a))
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white">AI Study Hub</h2>
        <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
          Leverage cognitive science and structured learning loops to ace your curriculum.
        </p>
      </div>

      {/* Sub Tabs */}
      <div className="flex border-b border-[#2C2C2C]/50 gap-6">
        {[
          { id: "tutor", label: "AI Concept Explainer", icon: BrainCircuit },
          { id: "flashcards", label: "Interactive Flashcards", icon: RotateCw },
          { id: "quiz", label: "Custom Practice Quizzes", icon: HelpCircle },
          { id: "tracker", label: "Assignments & Exams", icon: BookOpen },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className="pb-3 text-sm font-bold tracking-wide relative cursor-pointer flex items-center gap-2 transition-all"
              style={{
                color: isActive ? "white" : "#BDBDBD",
              }}
            >
              <Icon size={16} style={{ color: isActive ? accentColor : "#BDBDBD" }} />
              <span>{tab.label}</span>
              {isActive && (
                <motion.div
                  layoutId="activeStudySubTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5"
                  style={{ backgroundColor: accentColor }}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* 1. AI Concept Explainer View */}
      {activeSubTab === "tutor" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Concept Query</h3>
            <p className="text-xs text-gray-500">
              Input any subject, equation, programming concept, or topic you want broke down perfectly.
            </p>

            <div className="space-y-3">
              <textarea
                value={conceptInput}
                onChange={(e) => setConceptInput(e.target.value)}
                placeholder="e.g. Backpropagation in Neural Networks, The Spacing Effect, How photosynthesis splits water..."
                className="w-full h-24 bg-[#141414] border border-[#2C2C2C] rounded-2xl p-4 text-sm text-white focus:outline-hidden resize-none"
              />

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#BDBDBD] uppercase">Tutor Style</label>
                <div className="grid grid-cols-3 gap-1.5 bg-[#141414] p-1 border border-[#2C2C2C] rounded-xl">
                  {[
                    { id: "eli5", label: "ELI10" },
                    { id: "deep", label: "Deep Dive" },
                    { id: "analogies", label: "Analogies" },
                  ].map((style) => (
                    <button
                      key={style.id}
                      onClick={() => setExplainMode(style.id as any)}
                      className={`py-1.5 text-xs font-bold rounded-lg cursor-pointer ${
                        explainMode === style.id ? "bg-[#2C2C2C] text-white" : "text-gray-400 hover:text-white"
                      }`}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleExplainConcept}
                disabled={explainLoading || !conceptInput.trim()}
                className="w-full py-3 rounded-2xl text-black font-extrabold text-sm hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                style={{ backgroundColor: accentColor }}
              >
                {explainLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Decomposing Topic...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={16} />
                    <span>Explain with Gemini</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="lg:col-span-2 bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl min-h-[300px] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3 mb-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Tutor Explanation</h3>
                <span className="text-xs text-gray-500 font-semibold">Adaptive Learning Output</span>
              </div>

              {explanation ? (
                <div className="text-sm text-[#BDBDBD] leading-relaxed whitespace-pre-line font-medium max-w-3xl">
                  {explanation}
                </div>
              ) : explainLoading ? (
                <div className="space-y-4 py-8">
                  <div className="h-4 bg-[#2C2C2C] rounded-full animate-pulse w-3/4"></div>
                  <div className="h-4 bg-[#2C2C2C] rounded-full animate-pulse w-5/6"></div>
                  <div className="h-4 bg-[#2C2C2C] rounded-full animate-pulse w-1/2"></div>
                  <div className="h-4 bg-[#2C2C2C] rounded-full animate-pulse w-2/3"></div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center text-center py-16 text-gray-500 space-y-3">
                  <BrainCircuit size={32} />
                  <p className="text-xs font-semibold">Specify a concept on the left panel to begin active studying.</p>
                </div>
              )}
            </div>

            {explanation && (
              <div className="text-xs text-gray-500 border-t border-[#2C2C2C] pt-3 mt-6">
                💡 Review this material twice today to leverage spaced learning retention.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. Interactive Flashcards View */}
      {activeSubTab === "flashcards" && (
        <div className="max-w-xl mx-auto space-y-6">
          {/* Topic Generator bar */}
          <div className="flex gap-2.5 bg-[#1C1C1C] border border-[#2C2C2C] p-4 rounded-2xl items-center">
            <input
              type="text"
              value={flashcardTopic}
              onChange={(e) => setFlashcardTopic(e.target.value)}
              placeholder="e.g. Organic Chemistry, Calculus, Capital Assets Pricing Model"
              className="flex-1 bg-[#141414] border border-[#2C2C2C] rounded-xl px-4 py-2 text-sm text-white focus:outline-hidden"
            />
            <button
              onClick={handleGenerateFlashcards}
              disabled={flashcardsLoading || !flashcardTopic.trim()}
              className="px-4 py-2 rounded-xl text-black font-bold text-xs hover:opacity-90 transition-all cursor-pointer disabled:opacity-40 whitespace-nowrap"
              style={{ backgroundColor: accentColor }}
            >
              {flashcardsLoading ? "Generating..." : "Generate Cards"}
            </button>
          </div>

          {/* Flashcard Slider Deck */}
          {flashcards.length > 0 && (
            <div className="space-y-4">
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                className="h-72 w-full rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] flex flex-col items-center justify-center p-8 text-center cursor-pointer select-none transition-all duration-300 relative overflow-hidden group hover:border-[#BDBDBD]/20 shadow-xl"
              >
                {/* Floating decor */}
                <div className="absolute top-3 left-4 text-[10px] font-bold text-gray-500 tracking-wider">
                  CARD {currentCardIdx + 1} OF {flashcards.length}
                </div>
                <div className="absolute top-3 right-4 text-[10px] font-extrabold text-[#BDBDBD] uppercase tracking-widest bg-[#141414] px-2 py-0.5 rounded border border-[#2C2C2C]">
                  {isFlipped ? "ANSWER (BACK)" : "QUESTION (FRONT)"}
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={isFlipped ? "back" : "front"}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-4"
                  >
                    <p className={`text-white leading-relaxed ${isFlipped ? "text-sm font-semibold text-[#BDBDBD]" : "text-xl font-extrabold"}`}>
                      {isFlipped ? flashcards[currentCardIdx].answer : flashcards[currentCardIdx].question}
                    </p>
                  </motion.div>
                </AnimatePresence>

                <div className="absolute bottom-4 text-[10px] text-gray-500 font-bold uppercase tracking-wide flex items-center gap-1.5">
                  <RotateCw size={11} className="animate-spin" style={{ animationDuration: "10s" }} />
                  <span>Click to flip card</span>
                </div>
              </div>

              {/* Deck Navigation controls */}
              <div className="flex items-center justify-between">
                <button
                  onClick={() => {
                    setCurrentCardIdx((prev) => Math.max(0, prev - 1));
                    setIsFlipped(false);
                  }}
                  disabled={currentCardIdx === 0}
                  className="px-4 py-2.5 rounded-xl border border-[#2C2C2C] bg-[#1C1C1C] text-xs font-bold text-[#BDBDBD] hover:text-white cursor-pointer disabled:opacity-30 flex items-center gap-1.5"
                >
                  <ChevronLeft size={14} />
                  <span>Prev</span>
                </button>

                <span className="text-xs text-gray-500 font-bold">
                  Card {currentCardIdx + 1} of {flashcards.length}
                </span>

                <button
                  onClick={() => {
                    setCurrentCardIdx((prev) => Math.min(flashcards.length - 1, prev + 1));
                    setIsFlipped(false);
                  }}
                  disabled={currentCardIdx === flashcards.length - 1}
                  className="px-4 py-2.5 rounded-xl border border-[#2C2C2C] bg-[#1C1C1C] text-xs font-bold text-[#BDBDBD] hover:text-white cursor-pointer disabled:opacity-30 flex items-center gap-1.5"
                >
                  <span>Next</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. Custom Practice Quizzes View */}
      {activeSubTab === "quiz" && (
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Quiz generator panel */}
          <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-5 rounded-3xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">AI Quiz Generator</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input
                type="text"
                value={quizTopic}
                onChange={(e) => setQuizTopic(e.target.value)}
                placeholder="Quiz topic (e.g. Cognitive Psychology)"
                className="md:col-span-2 bg-[#141414] border border-[#2C2C2C] rounded-xl px-4 py-2 text-sm text-white focus:outline-hidden"
              />
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value)}
                className="bg-[#141414] border border-[#2C2C2C] rounded-xl px-3 py-2 text-xs text-white cursor-pointer outline-hidden font-bold"
              >
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Difficult">Difficult</option>
              </select>
            </div>
            <button
              onClick={handleGenerateQuiz}
              disabled={quizLoading || !quizTopic.trim()}
              className="w-full py-3 rounded-2xl text-black font-extrabold text-sm hover:opacity-90 transition-all cursor-pointer disabled:opacity-40 flex items-center justify-center gap-2"
              style={{ backgroundColor: accentColor }}
            >
              {quizLoading ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  <span>Synthesizing Exam Questions...</span>
                </>
              ) : (
                <>
                  <Sparkles size={16} />
                  <span>Compile AI Quiz</span>
                </>
              )}
            </button>
          </div>

          {/* Active Quiz Card Board */}
          {quizQuestions.length > 0 && (
            <div className="p-6 bg-[#1C1C1C] border border-[#2C2C2C] rounded-3xl space-y-6">
              <div className="flex items-center justify-between border-b border-[#2C2C2C] pb-3">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                  QUESTION {currentQuestionIdx + 1} OF {quizQuestions.length}
                </span>
                <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                  Difficulty: {difficulty}
                </span>
              </div>

              {/* Question Text */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-white leading-relaxed">
                  {quizQuestions[currentQuestionIdx].question}
                </h4>

                {/* Multiple choice options */}
                <div className="space-y-2.5">
                  {quizQuestions[currentQuestionIdx].options.map((option, oIdx) => {
                    const isSelected = selectedAnswers[currentQuestionIdx] === oIdx;
                    const isCorrect = quizQuestions[currentQuestionIdx].correctOptionIndex === oIdx;
                    
                    let optionStyle = "bg-[#141414] border-[#2C2C2C] text-white hover:border-[#BDBDBD]/20";
                    if (quizSubmitted) {
                      if (isCorrect) {
                        optionStyle = "bg-emerald-500/10 border-emerald-500 text-emerald-400 font-extrabold";
                      } else if (isSelected && !isCorrect) {
                        optionStyle = "bg-red-500/10 border-red-500 text-red-400 font-extrabold";
                      } else {
                        optionStyle = "bg-[#141414] border-[#2C2C2C]/50 text-gray-500";
                      }
                    } else if (isSelected) {
                      optionStyle = "bg-[#2C2C2C] text-white font-extrabold";
                    }

                    return (
                      <button
                        key={oIdx}
                        disabled={quizSubmitted}
                        onClick={() => {
                          setSelectedAnswers((prev) => ({ ...prev, [currentQuestionIdx]: oIdx }));
                        }}
                        className={`w-full text-left p-3.5 rounded-2xl border text-sm transition-all flex items-center justify-between cursor-pointer ${optionStyle}`}
                        style={{
                          borderColor: isSelected && !quizSubmitted ? accentColor : undefined,
                        }}
                      >
                        <span>{option}</span>
                        {quizSubmitted && isCorrect && <CheckCircle2 size={16} className="text-emerald-400" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Explanations block after submitting */}
              {quizSubmitted && (
                <div className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] text-xs leading-relaxed text-[#BDBDBD] space-y-1.5">
                  <span className="text-white font-extrabold block uppercase tracking-wider">AI TUTOR EXPLANATION</span>
                  <p>{quizQuestions[currentQuestionIdx].explanation}</p>
                </div>
              )}

              {/* Quiz Navigation bar */}
              <div className="flex items-center justify-between border-t border-[#2C2C2C] pt-4">
                <button
                  onClick={() => setCurrentQuestionIdx((prev) => Math.max(0, prev - 1))}
                  disabled={currentQuestionIdx === 0}
                  className="px-3.5 py-2 rounded-xl bg-[#141414] border border-[#2C2C2C] text-xs text-gray-400 hover:text-white cursor-pointer disabled:opacity-30"
                >
                  Back
                </button>

                {!quizSubmitted ? (
                  <button
                    onClick={() => setQuizSubmitted(true)}
                    disabled={Object.keys(selectedAnswers).length < quizQuestions.length}
                    className="px-5 py-2.5 rounded-2xl text-black font-extrabold text-xs cursor-pointer hover:opacity-95 disabled:opacity-40"
                    style={{ backgroundColor: accentColor }}
                  >
                    Submit Quiz
                  </button>
                ) : (
                  <div className="text-xs font-bold text-[#BDBDBD]">
                    Score: {quizQuestions.filter((q, idx) => selectedAnswers[idx] === q.correctOptionIndex).length}/{quizQuestions.length}
                  </div>
                )}

                <button
                  onClick={() => setCurrentQuestionIdx((prev) => Math.min(quizQuestions.length - 1, prev + 1))}
                  disabled={currentQuestionIdx === quizQuestions.length - 1}
                  className="px-3.5 py-2 rounded-xl bg-[#141414] border border-[#2C2C2C] text-xs text-gray-400 hover:text-white cursor-pointer disabled:opacity-30"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. Assignments & Exam Planner */}
      {activeSubTab === "tracker" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Lock Assignment</h3>
            <form onSubmit={handleCreateAssignment} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Assignment Title</label>
                <input
                  type="text"
                  required
                  value={newAssignTitle}
                  onChange={(e) => setNewAssignTitle(e.target.value)}
                  placeholder="e.g. CS-201 Final Essay"
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Course / Module</label>
                <input
                  type="text"
                  value={newAssignCourse}
                  onChange={(e) => setNewAssignCourse(e.target.value)}
                  placeholder="e.g. Computer Science"
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase tracking-wider">Due Date</label>
                <input
                  type="date"
                  value={newAssignDue}
                  onChange={(e) => setNewAssignDue(e.target.value)}
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-hidden cursor-pointer"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl text-black font-extrabold text-sm hover:opacity-90 transition-all cursor-pointer"
                style={{ backgroundColor: accentColor }}
              >
                Create Assignment
              </button>
            </form>
          </div>

          <div className="lg:col-span-2 bg-[#1C1C1C] border border-[#2C2C2C] p-6 rounded-3xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-[#2C2C2C] pb-3">Active Deliverables</h3>

            <div className="space-y-3">
              {assignments.map((item) => {
                const isOverdue = new Date(item.dueDate) < new Date() && !item.completed;
                return (
                  <div
                    key={item.id}
                    onClick={() => toggleAssignment(item.id)}
                    className="p-4 rounded-2xl bg-[#141414] border border-[#2C2C2C] hover:border-[#BDBDBD]/20 transition-all flex items-center justify-between cursor-pointer group"
                  >
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                          item.completed
                            ? "bg-emerald-500 border-emerald-500 text-black"
                            : "border-[#2C2C2C] group-hover:border-[#BDBDBD]"
                        }`}
                      >
                        {item.completed && <CheckCircle2 size={12} strokeWidth={3} />}
                      </div>
                      <div>
                        <span className={`text-sm font-bold block ${item.completed ? "text-gray-500 line-through" : "text-white"}`}>
                          {item.title}
                        </span>
                        <span className="text-[10px] text-gray-500 font-semibold uppercase">{item.course}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock size={12} className={isOverdue ? "text-red-400" : "text-gray-400"} />
                      <span className={`text-xs font-bold ${isOverdue ? "text-red-400" : "text-[#BDBDBD]"}`}>
                        Due: {item.dueDate}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
