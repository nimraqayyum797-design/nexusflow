import React from "react";

interface LogoProps {
  size?: number;
  showText?: boolean;
  className?: string;
  textClassName?: string;
  accentColor?: string;
}

export default function Logo({
  size = 48,
  showText = true,
  className = "",
  textClassName = "",
  accentColor = "#B6FF4D",
}: LogoProps) {
  // Generate a stable, fixed set of 32 radiating circuit board branches
  // to avoid random differences on each render.
  const branches = React.useMemo(() => {
    const list = [];
    const count = 36;
    for (let i = 0; i < count; i++) {
      const angle = (i * 2 * Math.PI) / count;
      
      // Determine if this path belongs to the left (blue/cyan) or right (green/lime) side
      const isLeft = Math.cos(angle) < 0;
      
      // Seeded-like variation based on the index to create organic wavy shapes
      const wave = Math.sin(i * 1.7) * 0.35;
      const wave2 = Math.cos(i * 2.3) * 0.2;
      
      const rStart = 26 + Math.abs(Math.sin(i * 3)) * 6;
      const rMid = 55 + Math.cos(i * 2) * 10;
      const rEnd = 78 + Math.sin(i * 4) * 8;
      
      // Compute coordinates
      const x1 = 100 + rStart * Math.cos(angle);
      const y1 = 100 + rStart * Math.sin(angle);
      
      const xMid = 100 + rMid * Math.cos(angle + wave);
      const yMid = 100 + rMid * Math.sin(angle + wave);
      
      const x2 = 100 + rEnd * Math.cos(angle + wave + wave2);
      const y2 = 100 + rEnd * Math.sin(angle + wave + wave2);
      
      // Node circle size variation
      const nodeSize = 1.8 + Math.abs(Math.sin(i * 5)) * 1.5;
      
      // Slight delay for animation triggers
      const delay = (i % 6) * 0.15;
      
      list.push({
        id: i,
        path: `M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${xMid.toFixed(1)} ${yMid.toFixed(1)}, ${x2.toFixed(1)} ${y2.toFixed(1)}`,
        cx: x2,
        cy: y2,
        nodeSize,
        isLeft,
        delay,
      });
    }
    return list;
  }, []);

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 filter drop-shadow-[0_0_8px_rgba(59,130,246,0.15)]"
      >
        <defs>
          {/* Blue/Cyan Gradient */}
          <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0055FF" />
            <stop offset="100%" stopColor="#00D8F6" />
          </linearGradient>
          
          {/* Green/Lime Gradient */}
          <linearGradient id="greenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00D8F6" />
            <stop offset="100%" stopColor="#35D07F" />
          </linearGradient>

          {/* Central N Gradient */}
          <linearGradient id="centerNGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#0066FF" />
            <stop offset="50%" stopColor="#00D8F6" />
            <stop offset="100%" stopColor="#35D07F" />
          </linearGradient>

          {/* Subtle Glow Filter */}
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Radiating Neuron / Circuit Traces */}
        {branches.map((b) => (
          <g key={b.id} className="opacity-75">
            {/* The circuit line path */}
            <path
              d={b.path}
              stroke={b.isLeft ? "url(#blueGrad)" : "url(#greenGrad)"}
              strokeWidth="1.2"
              strokeLinecap="round"
              fill="none"
              className="animate-pulse"
              style={{
                animationDuration: `${3 + (b.id % 4)}s`,
                animationDelay: `${b.delay}s`,
              }}
            />
            {/* The terminal node circle */}
            <circle
              cx={b.cx}
              cy={b.cy}
              r={b.nodeSize}
              fill={b.isLeft ? "#00D8F6" : "#35D07F"}
              className="animate-ping opacity-75"
              style={{
                animationDuration: `${4 + (b.id % 3)}s`,
                animationDelay: `${b.delay}s`,
              }}
            />
            <circle
              cx={b.cx}
              cy={b.cy}
              r={b.nodeSize}
              fill={b.isLeft ? "url(#blueGrad)" : "url(#greenGrad)"}
            />
          </g>
        ))}

        {/* Glowing Hub Underlay */}
        <circle cx="100" cy="100" r="28" fill="#0B0B0B" stroke="#222222" strokeWidth="1.5" />
        <circle cx="100" cy="100" r="24" fill="#111111" />

        {/* Central N Structure */}
        {/* Left vertical bar */}
        <path
          d="M 86 130 L 86 70"
          stroke="url(#centerNGrad)"
          strokeWidth="6"
          strokeLinecap="round"
        />
        {/* Middle diagonal bar */}
        <path
          d="M 86 70 L 114 130"
          stroke="url(#centerNGrad)"
          strokeWidth="6"
          strokeLinecap="round"
        />
        {/* Right vertical bar */}
        <path
          d="M 114 130 L 114 70"
          stroke="url(#centerNGrad)"
          strokeWidth="6"
          strokeLinecap="round"
        />

        {/* Circuit Intersections in the N */}
        <circle cx="86" cy="130" r="4" fill="#00D8F6" />
        <circle cx="86" cy="70" r="4" fill="#0055FF" />
        <circle cx="114" cy="130" r="4" fill="#35D07F" />
        <circle cx="114" cy="70" r="4" fill="#B6FF4D" />
      </svg>

      {showText && (
        <span className={`text-xl font-bold tracking-tight text-white ${textClassName}`}>
          <span className="text-[#00A3FF]">Nexus</span>
          <span className="text-[#35D07F]">Flow</span>
        </span>
      )}
    </div>
  );
}
