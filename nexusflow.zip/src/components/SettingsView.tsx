import { useState } from "react";
import { motion } from "motion/react";
import {
  Settings,
  Sparkles,
  Palette,
  Bell,
  Lock,
  User,
  ShieldCheck,
} from "lucide-react";

interface SettingsViewProps {
  accentColor: string;
  setAccentColor: (color: string) => void;
}

export default function SettingsView({ accentColor, setAccentColor }: SettingsViewProps) {
  const [aiSpeed, setAiSpeed] = useState("Balanced");
  const [promptStyle, setPromptStyle] = useState("Professional");
  const [remindSalah, setRemindSalah] = useState(true);
  const [remindWater, setRemindWater] = useState(true);
  const [remindBreak, setRemindBreak] = useState(true);

  const colors = [
    { name: "Neon Lime", value: "#B6FF4D" },
    { name: "Emerald Mint", value: "#76E84F" },
    { name: "Sky Blue", value: "#38BDF8" },
    { name: "Coral Rose", value: "#F43F5E" },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto p-1.5 md:p-4">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white">Settings</h2>
        <p className="text-sm text-[#BDBDBD] mt-1 font-medium">
          Customize your NexusFlow digital workspace. Manage AI behaviors, notification parameters, and themes.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Navigation / categories sidebar of settings */}
        <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-4 rounded-3xl h-fit space-y-2">
          {[
            { id: "appearance", label: "Appearance", icon: Palette },
            { id: "ai", label: "AI Preferences", icon: Sparkles },
            { id: "notifications", label: "Notifications", icon: Bell },
            { id: "security", label: "Security & Secrets", icon: Lock },
          ].map((sec) => {
            const Icon = sec.icon;
            return (
              <button
                key={sec.id}
                className="w-full text-left p-3 rounded-xl hover:bg-[#141414] text-sm text-[#BDBDBD] hover:text-white font-bold flex items-center gap-2.5 transition-colors cursor-pointer"
              >
                <Icon size={16} />
                <span>{sec.label}</span>
              </button>
            );
          })}
        </div>

        {/* Configurations content board */}
        <div className="md:col-span-2 space-y-6">
          {/* Section 1: Appearance */}
          <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4">
            <div className="flex items-center gap-2.5 border-b border-[#2C2C2C] pb-3">
              <Palette className="text-gray-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Accent Palette</h3>
            </div>

            <p className="text-xs text-[#BDBDBD]">
              Choose a signature high-contrast luxury theme color to style your buttons, headers, and visual charts.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 pt-1">
              {colors.map((c) => {
                const isSelected = accentColor === c.value;
                return (
                  <button
                    key={c.value}
                    onClick={() => setAccentColor(c.value)}
                    className="p-3.5 rounded-2xl bg-[#141414] border flex flex-col items-center justify-center text-center cursor-pointer transition-all gap-2 hover:border-gray-500/20"
                    style={{
                      borderColor: isSelected ? c.value : "#2C2C2C",
                    }}
                  >
                    <div className="w-5 h-5 rounded-full" style={{ backgroundColor: c.value }} />
                    <span className="text-[10px] font-bold text-white">{c.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: AI Preferences */}
          <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4">
            <div className="flex items-center gap-2.5 border-b border-[#2C2C2C] pb-3">
              <Sparkles className="text-gray-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">AI Coach Preferences</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase">AI Thinking Speed</label>
                <select
                  value={aiSpeed}
                  onChange={(e) => setAiSpeed(e.target.value)}
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-hidden cursor-pointer"
                >
                  <option value="Balanced">Balanced (Fast Response, High Quality)</option>
                  <option value="Max">Max Reasoning (Higher thinking latency)</option>
                  <option value="Minimal">Low Latency (Fast answers)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-[#BDBDBD] font-bold uppercase">AI Response Tone</label>
                <select
                  value={promptStyle}
                  onChange={(e) => setPromptStyle(e.target.value)}
                  className="w-full bg-[#141414] border border-[#2C2C2C] rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-hidden cursor-pointer"
                >
                  <option value="Professional">Wise & Strategic (Default)</option>
                  <option value="Actionable">Extremely Actionable (Clipped lists)</option>
                  <option value="Compassionate">Kind & Empathetic</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Notification center */}
          <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4">
            <div className="flex items-center gap-2.5 border-b border-[#2C2C2C] pb-3">
              <Bell className="text-gray-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Notification Parameters</h3>
            </div>

            <div className="space-y-3 pt-1">
              {[
                { id: "salah", label: "Salah/Prayer Reminders", desc: "Alert me 10 minutes prior to Dhuhr, Asr, Maghrib, and Isha.", val: remindSalah, setVal: setRemindSalah },
                { id: "water", label: "Hydration Nudges", desc: "Ping me every 2.5 hours to sustain optimal water levels.", val: remindWater, setVal: setRemindWater },
                { id: "break", label: "Sprints Break Alarm", desc: "Remind me to take a 5-minute break immediately after focus sprints.", val: remindBreak, setVal: setRemindBreak },
              ].map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => notif.setVal(!notif.val)}
                  className="flex items-center justify-between p-3 rounded-2xl bg-[#141414] border border-[#2C2C2C] cursor-pointer hover:border-gray-500/10 transition-all"
                >
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-white block">{notif.label}</span>
                    <span className="text-[10px] text-gray-500 block font-semibold">{notif.desc}</span>
                  </div>
                  <div
                    className={`w-10 h-6 rounded-full p-1 transition-colors ${
                      notif.val ? "bg-[#35D07F]" : "bg-[#2C2C2C]"
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full transition-transform ${
                        notif.val ? "translate-x-4" : "translate-x-0"
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 4: Security and credentials */}
          <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#2C2C2C] space-y-4">
            <div className="flex items-center gap-2.5 border-b border-[#2C2C2C] pb-3">
              <ShieldCheck className="text-emerald-400" size={18} />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Security & AI Key Status</h3>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-500/5 border border-emerald-500/10 flex items-start gap-3.5">
              <ShieldCheck size={18} className="text-emerald-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="text-xs font-bold text-white block">API Credentials Synchronized</span>
                <p className="text-[11px] text-[#BDBDBD] leading-relaxed">
                  Your Gemini AI services are fully configured server-side. Google AI Studio automatically mounts your `GEMINI_API_KEY` securely from the secrets panel. No manual keys needed.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
