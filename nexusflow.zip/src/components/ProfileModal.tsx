import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, User, Mail, Lock, Sparkles, CheckCircle2, AlertCircle, Save, Award } from "lucide-react";
import Logo from "./Logo";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: { name: string; email: string; role: string } | null;
  onUpdateUser: (updatedUser: { name: string; email: string; role: string }) => void;
  accentColor: string;
  setAccentColor: (color: string) => void;
}

export default function ProfileModal({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  accentColor,
  setAccentColor,
}: ProfileModalProps) {
  const [name, setName] = useState(currentUser?.name || "");
  const [email, setEmail] = useState(currentUser?.email || "");
  const [role, setRole] = useState(currentUser?.role || "");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const presetColors = [
    { name: "Neon Lime", value: "#B6FF4D" },
    { name: "Cyan Spark", value: "#00D8F6" },
    { name: "Emerald", value: "#35D07F" },
    { name: "Classic Blue", value: "#0066FF" },
    { name: "Amber", value: "#F59E0B" },
    { name: "Rose Glow", value: "#EC4899" },
  ];

  // Load the current user's password from local storage database if it exists
  React.useEffect(() => {
    if (isOpen && currentUser) {
      setName(currentUser.name);
      setEmail(currentUser.email);
      setRole(currentUser.role);
      
      const savedUsers = JSON.parse(localStorage.getItem("nexusflow_registered_users") || "[]");
      const matchedUser = savedUsers.find((u: any) => u.email.toLowerCase() === currentUser.email.toLowerCase());
      if (matchedUser) {
        setPassword(matchedUser.password || "");
      } else {
        setPassword("•••••");
      }
      setError("");
      setSuccess("");
    }
  }, [isOpen, currentUser]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!name || !email || !role) {
      setError("Name, email and role are required.");
      return;
    }

    setIsSaving(true);

    setTimeout(() => {
      setIsSaving(false);
      try {
        // Update user inside registered users list in local storage
        const savedUsers = JSON.parse(localStorage.getItem("nexusflow_registered_users") || "[]");
        let userFoundIndex = savedUsers.findIndex((u: any) => u.email.toLowerCase() === currentUser?.email.toLowerCase());

        const updatedUserData = {
          name,
          email,
          role,
          password: password !== "•••••" && password ? password : (savedUsers[userFoundIndex]?.password || "admin123"),
        };

        if (userFoundIndex >= 0) {
          savedUsers[userFoundIndex] = updatedUserData;
        } else {
          savedUsers.push(updatedUserData);
        }

        localStorage.setItem("nexusflow_registered_users", JSON.stringify(savedUsers));
        
        // Callback to trigger updates across the parent app
        onUpdateUser({
          name,
          email,
          role,
        });

        setSuccess("Profile successfully updated in local registry!");
        setTimeout(() => {
          onClose();
        }, 800);
      } catch (err) {
        setError("An error occurred while saving profile changes.");
        console.error(err);
      }
    }, 900);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#000000]/80 backdrop-blur-md cursor-pointer"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 15 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="w-full max-w-lg bg-[#111111] border border-[#262626] rounded-2xl overflow-hidden shadow-2xl relative z-10"
          >
            {/* Ambient Accent Light */}
            <div 
              className="absolute top-0 right-0 w-64 h-64 rounded-full blur-[100px] opacity-10 pointer-events-none transition-all duration-500"
              style={{ backgroundColor: accentColor }}
            />

            {/* Header */}
            <div className="p-5 border-b border-[#222222] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center border transition-all"
                  style={{ borderColor: `${accentColor}30`, backgroundColor: `${accentColor}10` }}
                >
                  <Award size={16} style={{ color: accentColor }} />
                </div>
                <div>
                  <h2 className="text-base font-extrabold text-white tracking-tight">
                    NexusFlow Identity Panel
                  </h2>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">
                    Profile Configurations
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-8 h-8 rounded-xl bg-[#1C1C1C] border border-[#2C2C2C] hover:border-gray-500 transition-colors flex items-center justify-center text-gray-400 hover:text-white cursor-pointer"
              >
                <X size={15} />
              </button>
            </div>

            {/* Form Details */}
            <form onSubmit={handleSave} className="p-6 flex flex-col gap-5">
              {/* Display Header Badge */}
              <div className="bg-[#161616] border border-[#222222] p-4 rounded-xl flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#0055FF]/10 to-[#35D07F]/10 border border-[#262626] flex items-center justify-center text-xl font-black tracking-widest text-white shadow-inner">
                  {name ? name.slice(0, 2).toUpperCase() : "NF"}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-white truncate">{name || "Nimra"}</span>
                    <span 
                      className="text-[9px] px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider"
                      style={{ backgroundColor: `${accentColor}20`, color: accentColor }}
                    >
                      Active Profile
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5 truncate">{email || "nimra@gmail.com"}</p>
                  <p className="text-[11px] text-gray-500 mt-1 font-semibold truncate flex items-center gap-1">
                    <Sparkles size={11} className="text-gray-600" /> {role || "Productive Creator"}
                  </p>
                </div>
              </div>

              {/* Grid Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Full Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                    <User size={11} /> Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-2.5 px-3.5 text-xs font-semibold outline-none transition-all text-white"
                  />
                </div>

                {/* Email Address */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                    <Mail size={11} /> Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-2.5 px-3.5 text-xs font-semibold outline-none transition-all text-white"
                  />
                </div>

                {/* Security Password */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                    <Lock size={11} /> Security Password
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter security password"
                    className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-2.5 px-3.5 text-xs font-semibold outline-none transition-all text-white"
                  />
                </div>

                {/* Custom Role / Tagline */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                    <Sparkles size={11} /> Workspace Role
                  </label>
                  <input
                    type="text"
                    required
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full bg-[#181818] border border-[#262626] focus:border-gray-500 rounded-xl py-2.5 px-3.5 text-xs font-semibold outline-none transition-all text-white"
                  />
                </div>
              </div>

              {/* Accent Color Configurator inside Profile */}
              <div className="bg-[#161616]/50 border border-[#222222]/60 p-4 rounded-xl flex flex-col gap-2.5">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gray-500 flex items-center gap-1">
                  💡 Sync Workspace Accent Theme
                </span>
                <div className="flex items-center gap-2.5 mt-0.5 flex-wrap">
                  {presetColors.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setAccentColor(color.value)}
                      type="button"
                      title={color.name}
                      className="w-5.5 h-5.5 rounded-full border transition-all relative flex items-center justify-center cursor-pointer"
                      style={{ 
                        backgroundColor: color.value,
                        borderColor: accentColor === color.value ? "#FFFFFF" : "transparent",
                        boxShadow: accentColor === color.value ? `0 0 10px ${color.value}` : "none",
                        transform: accentColor === color.value ? "scale(1.12)" : "scale(1)"
                      }}
                    >
                      {accentColor === color.value && (
                        <div className="w-1.5 h-1.5 rounded-full bg-[#080808]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status Notifications */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-rose-950/40 border border-rose-850 p-3 rounded-xl flex items-start gap-2 text-xs text-rose-300"
                >
                  <AlertCircle size={14} className="shrink-0 mt-0.5" />
                  <span>{error}</span>
                </motion.div>
              )}

              {success && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-emerald-950/40 border border-emerald-850 p-3 rounded-xl flex items-start gap-2 text-xs text-emerald-300"
                >
                  <CheckCircle2 size={14} className="shrink-0 mt-0.5" />
                  <span>{success}</span>
                </motion.div>
              )}

              {/* Form Footer */}
              <div className="mt-2 flex items-center justify-end gap-3 pt-4 border-t border-[#222222]">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-400 hover:text-white hover:bg-[#1C1C1C] transition-colors cursor-pointer border border-[#222222]"
                >
                  Dismiss
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 rounded-xl text-black font-extrabold text-xs transition-all flex items-center gap-2 cursor-pointer hover:brightness-110 disabled:opacity-50"
                  style={{ backgroundColor: accentColor }}
                >
                  {isSaving ? (
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Save size={13} />
                      <span>Save Settings</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
