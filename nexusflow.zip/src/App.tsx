import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

// Types
import {
  Category,
  Priority,
  EnergyLevel,
  Task,
  Habit,
  Goal,
  TimelineItem,
  DailyPrayer,
  Note,
  AssistantMessage,
} from "./types";

// Components
import Sidebar from "./components/Sidebar";
import DashboardView from "./components/DashboardView";
import AssistantView from "./components/AssistantView";
import TasksView from "./components/TasksView";
import GoalsView from "./components/GoalsView";
import HabitsView from "./components/HabitsView";
import StudyView from "./components/StudyView";
import IslamicView from "./components/IslamicView";
import CalendarView from "./components/CalendarView";
import JournalView from "./components/JournalView";
import AnalyticsView from "./components/AnalyticsView";
import SettingsView from "./components/SettingsView";
import LoginPage from "./components/LoginPage";
import ProfileModal from "./components/ProfileModal";

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [accentColor, setAccentColor] = useState("#B6FF4D"); // Premium Neon Lime
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string; role: string } | null>(() => {
    try {
      const saved = localStorage.getItem("nexusflow_current_user");
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      console.error(e);
      return null;
    }
  });

  // Load state helpers
  const loadState = <T,>(key: string, defaultValue: T): T => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : defaultValue;
    } catch (e) {
      console.error(e);
      return defaultValue;
    }
  };

  // 1. Tasks state
  const [tasks, setTasks] = useState<Task[]>(() =>
    loadState<Task[]>("nexusflow_tasks", [
      {
        id: "task_1",
        title: "Structure academic paper roadmap",
        description: "Break down core chapters for Artificial Intelligence thesis.",
        category: Category.Study,
        priority: Priority.High,
        energyLevel: EnergyLevel.High,
        estimatedMinutes: 60,
        focusTimeSpent: 0,
        subtasks: [
          { id: "sub_1", title: "Review 3 citation papers", completed: true, estimatedMinutes: 20 },
          { id: "sub_2", title: "Draft thesis statement", completed: false, estimatedMinutes: 15 },
          { id: "sub_3", title: "AI tutor breakdown outline", completed: false, estimatedMinutes: 25 },
        ],
        status: "in_progress",
        dueDate: "2026-07-28",
      },
      {
        id: "task_2",
        title: "Memorize last 10 Surahs of Quran",
        description: "Sustain daily revision streak after Fajr.",
        category: Category.Faith,
        priority: Priority.Medium,
        energyLevel: EnergyLevel.Normal,
        estimatedMinutes: 30,
        focusTimeSpent: 0,
        subtasks: [],
        status: "todo",
        dueDate: "2026-07-25",
      },
      {
        id: "task_3",
        title: "Build NexusFlow dashboard layout",
        description: "Focus on apple-level premium dark mode aesthetics.",
        category: Category.Work,
        priority: Priority.High,
        energyLevel: EnergyLevel.High,
        estimatedMinutes: 120,
        focusTimeSpent: 45,
        subtasks: [],
        status: "completed",
        dueDate: "2026-07-23",
      },
    ])
  );

  // 2. Habits state
  const [habits, setHabits] = useState<Habit[]>(() =>
    loadState<Habit[]>("nexusflow_habits", [
      {
        id: "habit_1",
        name: "Read 5 Pages of Quran Daily",
        frequency: "Daily",
        category: Category.Faith,
        streak: 12,
        completedDays: ["2026-07-22", "2026-07-21", "2026-07-20"],
        consistencyScore: 85,
      },
      {
        id: "habit_2",
        name: "Morning Deep Study Sprint",
        frequency: "Daily",
        category: Category.Study,
        streak: 5,
        completedDays: ["2026-07-22", "2026-07-20"],
        consistencyScore: 71,
      },
      {
        id: "habit_3",
        name: "Drink 2500ml of Water",
        frequency: "Daily",
        category: Category.Health,
        streak: 8,
        completedDays: ["2026-07-23", "2026-07-22", "2026-07-21"],
        consistencyScore: 100,
      },
    ])
  );

  // 3. Goals state
  const [goals, setGoals] = useState<Goal[]>(() =>
    loadState<Goal[]>("nexusflow_goals", [
      {
        id: "goal_1",
        title: "Launch full-stack SaaS product",
        targetDate: "2026-09-30",
        category: Category.Work,
        progress: 60,
        subGoals: [
          { id: "sg_1", title: "Complete interactive visual dashboard", completed: true },
          { id: "sg_2", title: "Integrate server-side Gemini API securely", completed: true },
          { id: "sg_3", title: "Scale database and billing engine", completed: false },
        ],
        status: "active",
      },
      {
        id: "goal_2",
        title: "Complete Tajweed recitation certification",
        targetDate: "2026-12-15",
        category: Category.Faith,
        progress: 0,
        subGoals: [
          { id: "sg_4", title: "Study rules of Noon Sakinah", completed: false },
          { id: "sg_5", title: "Sustain daily pages streak tracker", completed: false },
        ],
        status: "active",
      },
    ])
  );

  // 4. Notes & Journal state
  const [notes, setNotes] = useState<Note[]>(() =>
    loadState<Note[]>("nexusflow_notes", [
      {
        id: "note_1",
        title: "Fajr Routine Optimization",
        content: "I felt exceptionally alert studying between 5:30 AM and 7 AM. The brain is quiet, distractions are zero, and barakah is extremely high. Schedule difficult reading blocks here.",
        category: Category.Personal,
        updatedAt: "Jul 23, 2026",
      },
      {
        id: "note_2",
        title: "Artificial Intelligence Roadmap",
        content: "Focusing on large language models (LLMs) and context engineering. Gemini 3.6 Flash is highly useful for subtask breakdowns and explanations.",
        category: Category.Study,
        updatedAt: "Jul 21, 2026",
      },
    ])
  );

  // 5. Prayers Tracker state
  const [prayers, setPrayers] = useState<DailyPrayer[]>(() =>
    loadState<DailyPrayer[]>("nexusflow_prayers", [
      { id: "pr_1", name: "Fajr", time: "04:32 AM", completed: true },
      { id: "pr_2", name: "Dhuhr", time: "12:45 PM", completed: false },
      { id: "pr_3", name: "Asr", time: "04:15 PM", completed: false },
      { id: "pr_4", name: "Maghrib", time: "07:12 PM", completed: false },
      { id: "pr_5", name: "Isha", time: "08:45 PM", completed: false },
    ])
  );

  // 6. Timeline Item Sprints
  const [timeline, setTimeline] = useState<TimelineItem[]>(() =>
    loadState<TimelineItem[]>("nexusflow_timeline", [
      { id: "tl_1", time: "04:30 AM", title: "Wake Up & Fajr Prayer", type: "Prayer", completed: true },
      { id: "tl_2", time: "05:15 AM", title: "Quran Memorization Block", type: "Reading", completed: true },
      { id: "tl_3", time: "09:00 AM", title: "Deep Work: Academic Research", type: "Study", completed: false, notes: "Use AI tutor for concept outlines." },
      { id: "tl_4", time: "12:45 PM", title: "Dhuhr Prayer & Rest break", type: "Prayer", completed: false },
      { id: "tl_5", time: "03:00 PM", title: "SaaS Sprints Development", type: "Focus", completed: false },
      { id: "tl_6", time: "06:00 PM", title: "Cardio workout sprint", type: "Exercise", completed: false },
    ])
  );

  // 7. Conversational Chat Histories for separate active assistants
  const [chatHistories, setChatHistories] = useState<{ [key: string]: AssistantMessage[] }>(() =>
    loadState<{ [key: string]: AssistantMessage[] }>("nexusflow_chat", {
      coach: [],
      tutor: [],
      focus: [],
      faith: [],
    })
  );

  // Today's metrics state
  const [focusTimeToday, setFocusTimeToday] = useState(() => loadState<number>("nexusflow_focus_time", 45));
  const [studyTimeToday, setStudyTimeToday] = useState(() => loadState<number>("nexusflow_study_time", 2.5));
  const [waterIntake, setWaterIntake] = useState(() => loadState<number>("nexusflow_water", 1250));

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem("nexusflow_tasks", JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem("nexusflow_habits", JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem("nexusflow_goals", JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem("nexusflow_notes", JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem("nexusflow_prayers", JSON.stringify(prayers));
  }, [prayers]);

  useEffect(() => {
    localStorage.setItem("nexusflow_timeline", JSON.stringify(timeline));
  }, [timeline]);

  useEffect(() => {
    localStorage.setItem("nexusflow_chat", JSON.stringify(chatHistories));
  }, [chatHistories]);

  useEffect(() => {
    localStorage.setItem("nexusflow_focus_time", JSON.stringify(focusTimeToday));
  }, [focusTimeToday]);

  useEffect(() => {
    localStorage.setItem("nexusflow_study_time", JSON.stringify(studyTimeToday));
  }, [studyTimeToday]);

  useEffect(() => {
    localStorage.setItem("nexusflow_water", JSON.stringify(waterIntake));
  }, [waterIntake]);

  // Handlers
  const handleTogglePrayer = (id: string) => {
    setPrayers((prev) =>
      prev.map((p) => (p.id === id ? { ...p, completed: !p.completed } : p))
    );
  };

  const handleToggleTimelineItem = (id: string) => {
    setTimeline((prev) =>
      prev.map((item) => (item.id === id ? { ...item, completed: !item.completed } : item))
    );
  };

  // Render sub-view matching active sidebar tab
  const renderView = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <DashboardView
            tasks={tasks}
            habits={habits}
            prayers={prayers}
            timeline={timeline}
            focusTimeToday={focusTimeToday}
            studyTimeToday={studyTimeToday}
            waterIntake={waterIntake}
            setWaterIntake={setWaterIntake}
            togglePrayer={handleTogglePrayer}
            toggleTimelineItem={handleToggleTimelineItem}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            accentColor={accentColor}
          />
        );
      case "assistant":
        return (
          <AssistantView
            chatHistories={chatHistories}
            setChatHistories={setChatHistories}
            accentColor={accentColor}
          />
        );
      case "tasks":
        return <TasksView tasks={tasks} setTasks={setTasks} accentColor={accentColor} />;
      case "goals":
        return <GoalsView goals={goals} setGoals={setGoals} accentColor={accentColor} />;
      case "habits":
        return <HabitsView habits={habits} setHabits={setHabits} accentColor={accentColor} />;
      case "study":
        return <StudyView accentColor={accentColor} />;
      case "islamic":
        return (
          <IslamicView
            prayers={prayers}
            togglePrayer={handleTogglePrayer}
            accentColor={accentColor}
          />
        );
      case "calendar":
        return (
          <CalendarView
            timeline={timeline}
            toggleTimelineItem={handleToggleTimelineItem}
            accentColor={accentColor}
          />
        );
      case "journal":
        return <JournalView notes={notes} setNotes={setNotes} accentColor={accentColor} />;
      case "analytics":
        return (
          <AnalyticsView
            tasks={tasks}
            habits={habits}
            prayers={prayers}
            focusTimeToday={focusTimeToday}
            studyTimeToday={studyTimeToday}
            accentColor={accentColor}
          />
        );
      case "settings":
        return <SettingsView accentColor={accentColor} setAccentColor={setAccentColor} />;
      default:
        return (
          <div className="h-full flex items-center justify-center text-[#BDBDBD]">
            Tab '{activeTab}' is currently in development.
          </div>
        );
    }
  };

  if (!currentUser) {
    return (
      <LoginPage
        onLogin={(user) => {
          setCurrentUser(user);
          localStorage.setItem("nexusflow_current_user", JSON.stringify(user));
        }}
        accentColor={accentColor}
        setAccentColor={setAccentColor}
      />
    );
  }

  return (
    <div className="bg-[#0B0B0B] text-white min-h-screen flex font-sans antialiased selection:bg-[#B6FF4D]/30 select-none">
      {/* Left Navigation Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        collapsed={collapsed}
        setCollapsed={setCollapsed}
        accentColor={accentColor}
        currentUser={currentUser}
        onLogOut={() => {
          setCurrentUser(null);
          localStorage.removeItem("nexusflow_current_user");
        }}
      />

      {/* Main Content Pane */}
      <main className="flex-1 overflow-y-auto h-screen relative bg-[#0B0B0B]">
        {/* Subtle decorative glowing background light blur */}
        <div className="absolute top-0 left-1/4 w-[45rem] h-[35rem] bg-indigo-500/3 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-10 right-1/4 w-[35rem] h-[35rem] bg-amber-500/2 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header containing search summaries or profile logs */}
        <header className="px-6 py-4 border-b border-[#2C2C2C]/30 bg-[#0B0B0B]/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between select-none">
          <div className="flex items-center gap-4">
            {/* Clickable Profile Circle Trigger */}
            <button
              onClick={() => setShowProfileModal(true)}
              title="View and Edit Profile"
              className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#0055FF]/10 to-[#35D07F]/10 border border-[#2C2C2C] hover:border-gray-500 transition-all flex items-center justify-center text-xs font-black tracking-widest text-white shadow-inner shrink-0 group cursor-pointer relative"
            >
              {/* Pulsing indicator to show it's interactive */}
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-[#0B0B0B] animate-pulse"></span>
              <span className="group-hover:scale-105 transition-transform">
                {currentUser?.name ? currentUser.name.slice(0, 2).toUpperCase() : "NF"}
              </span>
            </button>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                WORKSPACE
              </span>
              <span className="text-xs text-gray-400">/</span>
              <span className="text-xs font-black text-white uppercase tracking-wider">
                {activeTab}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Quick stats banner */}
            <div className="hidden sm:flex items-center gap-3 text-xs bg-[#141414] border border-[#2C2C2C] px-3.5 py-1.5 rounded-xl">
              <span className="text-gray-400 font-medium">Daily Streak:</span>
              <span className="font-extrabold text-[#35D07F]">🔥 12 Days</span>
            </div>

            <div className="hidden sm:flex items-center gap-3 text-xs bg-[#141414] border border-[#2C2C2C] px-3.5 py-1.5 rounded-xl">
              <span className="text-gray-400 font-medium">Fajr Focus Block:</span>
              <span className="font-extrabold text-amber-400">Locked</span>
            </div>
          </div>
        </header>

        {/* View Transition Frame */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.22, ease: "easeInOut" }}
            >
              {renderView()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Profile Modal */}
      <ProfileModal
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        currentUser={currentUser}
        onUpdateUser={(updatedUser) => {
          setCurrentUser(updatedUser);
          localStorage.setItem("nexusflow_current_user", JSON.stringify(updatedUser));
        }}
        accentColor={accentColor}
        setAccentColor={setAccentColor}
      />
    </div>
  );
}
