import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize GoogleGenAI server-side with User-Agent telemetry
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    })
  : null;

app.use(express.json());

// API endpoints FIRST

// 1. General chat for NexusFlow AI Assistants (Coach, Study Tutor, Faith Companion, Focus Guide)
app.post("/api/gemini/chat", async (req, res) => {
  if (!ai) {
    return res.status(500).json({
      error: "Gemini API key is not configured. Please add GEMINI_API_KEY to your secrets.",
    });
  }

  const { messages, assistantType } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid messages format" });
  }

  // System instruction based on the active assistant persona
  let systemInstruction = "You are NexusFlow AI, an elite, futuristic, elegant, and ultra-competent productivity assistant.";
  
  if (assistantType === "coach") {
    systemInstruction = `You are the NexusFlow AI Life Coach. You are wise, motivating, empathetic, and highly strategic.
Your goal is to help Nimra define high-impact personal goals, break down mental blocks, plan routines, overcome procrastination, and stay motivated.
Provide extremely polished, actionable, and inspiring advice. Keep your tone sophisticated, calm, and encouraging. Use elegant formatting.`;
  } else if (assistantType === "tutor") {
    systemInstruction = `You are the NexusFlow AI Study Tutor. You are exceptionally intelligent, clear-headed, and structured.
Your goal is to explain complex academic, professional, or general concepts perfectly, create study schedules, and design custom learning roadmaps.
Always break down concepts step-by-step. Use formatting, bold headers, and short bullet points to make things ultra-readable.`;
  } else if (assistantType === "faith") {
    systemInstruction = `You are the NexusFlow Islamic Productivity Companion. You combine modern productivity principles with timeless Islamic wisdom.
Your goal is to help Nimra balance spiritual obligations (like Salah, Quran, Dhikr) with daily studies, work, and wellness.
Speak with deep respect, kindness, and wisdom. Suggest beautiful, practical ways to integrate faith into a busy lifestyle (e.g., using Barakah, focusing after Fajr, keeping consistent habits).`;
  } else if (assistantType === "focus") {
    systemInstruction = `You are the NexusFlow AI Focus Assistant. You are tactical, crisp, and direct.
Your goal is to help Nimra block out distractions, structure deep work sprints, manage cognitive energy levels, and enter deep flow states.
Keep your answers brief, high-energy, and highly actionable. Give her quick focus exercises, pomodoro structures, or immediate tips to get back to work.`;
  }

  try {
    // Map previous messages to content parts
    const contents = messages.map((m: any) => {
      return {
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      };
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Chat error:", error);
    res.status(500).json({ error: error.message || "An error occurred with the AI model." });
  }
});

// 2. AI Subtask Generator for Tasks Panel
app.post("/api/gemini/subtasks", async (req, res) => {
  if (!ai) {
    return res.status(500).json({ error: "Gemini API key is not configured." });
  }

  const { taskTitle, taskDescription, energyLevel } = req.body;
  if (!taskTitle) {
    return res.status(400).json({ error: "Task title is required" });
  }

  const prompt = `Break down the following task into a logical, step-by-step sequence of 3 to 6 micro-tasks (subtasks).
Task Title: ${taskTitle}
Description: ${taskDescription || "None provided"}
User current energy level: ${energyLevel || "Normal"}

Make the subtasks highly specific and actionable. For each subtask, estimate the time required in minutes.

Return the response STRICTLY as a JSON array where each object has "title" (string) and "estimatedMinutes" (number) properties.
Do not wrap in markdown blocks, just return raw JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "Actionable micro-task title" },
              estimatedMinutes: { type: Type.INTEGER, description: "Estimated completion time in minutes" },
            },
            required: ["title", "estimatedMinutes"],
          },
        },
      },
    });

    const subtasks = JSON.parse(response.text || "[]");
    res.json({ subtasks });
  } catch (error: any) {
    console.error("Subtask generation error:", error);
    res.status(500).json({ error: "Failed to generate subtasks. Please try again." });
  }
});

// 3. AI Study Tutor "Explain Concept"
app.post("/api/gemini/study/explain", async (req, res) => {
  if (!ai) {
    return res.status(500).json({ error: "Gemini API key is not configured." });
  }

  const { concept, mode } = req.body;
  if (!concept) {
    return res.status(400).json({ error: "Concept is required" });
  }

  let prompt = "";
  if (mode === "eli5") {
    prompt = `Explain the following concept like I am a 10-year old student. Use simple metaphors, clear analogies, and no complicated jargon. Keep it exceptionally engaging and clear:
Concept: ${concept}`;
  } else if (mode === "deep") {
    prompt = `Provide a comprehensive, high-level structured academic explanation of the following concept. Include key components, real-world relevance, technical details, and a quick summary:
Concept: ${concept}`;
  } else {
    prompt = `Explain the following concept using 3 rich, creative, and memorable real-world analogies. Help me fully visualize and remember it easily:
Concept: ${concept}`;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an elite Nobel Prize-winning teacher who explains complex concepts with perfect clarity, beautiful formatting, and inspiring tone.",
      },
    });

    res.json({ explanation: response.text });
  } catch (error: any) {
    console.error("Study explain error:", error);
    res.status(500).json({ error: "Failed to generate explanation." });
  }
});

// 4. AI Flashcard Generator
app.post("/api/gemini/study/flashcards", async (req, res) => {
  if (!ai) {
    return res.status(500).json({ error: "Gemini API key is not configured." });
  }

  const { topic } = req.body;
  if (!topic) {
    return res.status(400).json({ error: "Topic is required" });
  }

  const prompt = `Create a list of 5 high-yield revision flashcards for the topic: "${topic}".
Each flashcard must contain a clear, challenging "question" on the front, and a comprehensive, concise "answer" on the back.

Return the response STRICTLY as a JSON array of objects with "question" and "answer" fields. Do not include markdown wraps.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              answer: { type: Type.STRING },
            },
            required: ["question", "answer"],
          },
        },
      },
    });

    const flashcards = JSON.parse(response.text || "[]");
    res.json({ flashcards });
  } catch (error: any) {
    console.error("Flashcards generation error:", error);
    res.status(500).json({ error: "Failed to generate flashcards." });
  }
});

// 5. AI Quiz Generator
app.post("/api/gemini/study/quiz", async (req, res) => {
  if (!ai) {
    return res.status(500).json({ error: "Gemini API key is not configured." });
  }

  const { topic, difficulty } = req.body;
  if (!topic) {
    return res.status(400).json({ error: "Topic is required" });
  }

  const prompt = `Generate a 4-question multiple-choice quiz on the topic: "${topic}".
Difficulty level: ${difficulty || "Medium"}.

Each question must have:
1. "question" (string)
2. "options" (array of 4 strings)
3. "correctOptionIndex" (integer 0-3 representing the index of the correct option)
4. "explanation" (string explaining why that option is correct)

Return the response STRICTLY as a JSON array of objects following the defined schema.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              correctOptionIndex: { type: Type.INTEGER },
              explanation: { type: Type.STRING },
            },
            required: ["question", "options", "correctOptionIndex", "explanation"],
          },
        },
      },
    });

    const quiz = JSON.parse(response.text || "[]");
    res.json({ quiz });
  } catch (error: any) {
    console.error("Quiz generation error:", error);
    res.status(500).json({ error: "Failed to generate quiz." });
  }
});

// 6. AI Productivity Analytics & Insights
app.post("/api/gemini/insights", async (req, res) => {
  if (!ai) {
    return res.status(500).json({ error: "Gemini API key is not configured." });
  }

  const { habits, tasks, focusLogs, currentGoals, mood, energyLogs } = req.body;

  const prompt = `Act as the NexusFlow AI Productivity Auditor. Analyze Nimra's performance metrics and provide high-level, ultra-strategic insights.
Metrics:
- Habits Completion Track: ${JSON.stringify(habits || {})}
- Tasks Track (Completed vs Pending): ${JSON.stringify(tasks || {})}
- Focus Sprints Logs (Minutes): ${JSON.stringify(focusLogs || [])}
- Active Goals: ${JSON.stringify(currentGoals || [])}
- Mood & Energy patterns: Mood is ${mood || "Stable"}, Energy is ${JSON.stringify(energyLogs || [])}

Provide:
1. **Focus Optimization Score** (0-100) and brief justification.
2. **Key Productivity Discovery**: Highlight 1 major pattern (e.g., correlation of focus with specific hours or habits).
3. **Spiritual & Material Balance**: A recommendation on aligning faith goals (Quran, Praying, Salah) with focus hours.
4. **Immediate Next Action**: Provide 1 hyper-specific action she should take in the next hour to maintain flow.

Format the output strictly as a JSON object with these fields:
"focusScore" (number), "scoreJustification" (string), "productivityDiscovery" (string), "faithBalanceInsight" (string), "immediateAction" (string).`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            focusScore: { type: Type.INTEGER },
            scoreJustification: { type: Type.STRING },
            productivityDiscovery: { type: Type.STRING },
            faithBalanceInsight: { type: Type.STRING },
            immediateAction: { type: Type.STRING },
          },
          required: ["focusScore", "scoreJustification", "productivityDiscovery", "faithBalanceInsight", "immediateAction"],
        },
      },
    });

    const insights = JSON.parse(response.text || "{}");
    res.json({ insights });
  } catch (error: any) {
    console.error("Insights error:", error);
    res.status(500).json({ error: "Failed to audit productivity metrics." });
  }
});

// Mounting Vite middleware in development or serving compiled build in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NexusFlow Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start full-stack server:", err);
});
